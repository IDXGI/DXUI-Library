﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 棋盘.rc 使用
//
#define IDI_MY                          107
#define IDI_SMALL                       108
#define IDR_IMG1                        130
#define IDB_PNG1                        131
#define IDB_PNG2                        132
#define IDB_PNG3                        133
#define IDB_PNG4                        134
#define IDB_PNG5                        135
#define IDB_PNG6                        136
#define IDB_PNG7                        137
#define IDB_PNG8                        138
#define IDB_PNG9                        139
#define IDB_PNG10                       140
#define IDB_PNG11                       141
#define IDB_PNG12                       142
#define IDB_PNG13                       143
#define IDB_PNG14                       144

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
