#include "Main.h"

DWindow Main;

DLinearColorBox TiB;
DLabel Ti;
DButton Close;
DButton MinSize;
DSolidColorBox PlanViewB;
DScrollView PlanView;
DButton PackMgr;
DImageBox PackImg;
DButton NewPlan;
DButton DelPlan;

DBezier b = { 0.16f, 1.0f, 0.3f, 1.0f };
HINSTANCE hInst = nullptr;//��ǰʵ��

//�������Ӵ���
PackMgrUI MgrWnd;//������������
PackEditUI EditWnd;//���༭������

//�б����
typedef struct _tagPlanItem
{
	DSolidColorBox* Back;
	DImageBox* Icon;
	DLabel* Name;
	DButton* Del;
}PlanItem;

std::map<UINT, PlanItem> plans;
___DThreadLock planLock;
float PlanFullHeight = 0.0f;
#define PlanSpacing 7.0f

//�����ڵĲ�������
#define Title       L"û��ն - DXUI Demo"//�������ı�
#define WindowClass L"NoCiZhan Class"//����������
#define WindowWidth  740
#define WindowHeight 500

void __stdcall DConProc(HWND hWnd, UINT id, DControlType type, DControlMsg msg, WPARAM wParam, LPARAM lParam);
BOOL InitInstance(HINSTANCE);

void AddPlan();
void DeletePlan();

int APIENTRY wWinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPWSTR lpCmdLine, _In_ int nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);
	UNREFERENCED_PARAMETER(nCmdShow);

	hInst = hInstance;

	//ִ��Ӧ�ó����ʼ��:
	if (!InitInstance(hInstance))
		return false;

	MSG msg;

	//����Ϣѭ��:
	while (GetMessageW(&msg, nullptr, 0, 0))
	{
		if (!TranslateAcceleratorW(msg.hwnd, nullptr, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessageW(&msg);
		}
	}
	return (int)msg.wParam;
}

BOOL InitInstance(HINSTANCE hInstance)
{
	hInst = hInstance; // ��ʵ������洢��ȫ�ֱ�����
	if (!Main.Create(hInst, WindowClass, Title, WndProc, WindowWidth, WindowHeight))
		return false;

	DColorBox_Point p[2];
	p[0].color = { 0, 236, 116, 1.0f };
	p[0].position = 0.0f;
	p[1].color = { 0, 174, 247, 1.0f };
	p[1].position = 1.0f;

	TiB.Init({ 0, 0 }, { WindowWidth, 40 }, { 0, 0, 0, 0.0f }, p, 2, { 0, 40 }, { WindowWidth, 0 }, { 0 }, 0.0f, 0.0f, 0.0f, true);

	Ti.Init({ 150, 0 }, { WindowWidth - 300, 40 },
		{ { 255, 255, 255, 1.0f }, false, false, 0 },
		{ { 255, 255, 255, 1.0f }, false, false, 0 },
		{ { 255, 255, 255, 1.0f }, false, false, 0 },
		true, Title, L"΢���ź�", 20, false, DFontWeight::Medium, DAlignment::Center, DAlignment::Center);

	Close.Init({ WindowWidth - 35, 0 }, { 35, 35 },
		{ { 255, 60, 40, 0.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 255, 70, 50, 0.8f }, { 200, 200, 200, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 150, 50, 30, 1.0f }, { 150, 150, 200, 0.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		0.0f, 0.0f, 0.0f, L"��", L"΢���ź�", 30, DFontWeight::Light);

	MinSize.Init({ WindowWidth - 70, 0 }, { 35, 35 },
		{ { 255, 255, 255, 0.0f }, { 26, 217, 110, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 255, 255, 255, 0.4f }, { 35, 231, 131, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 255, 255, 255, 0.6f }, { 31, 207, 108, 1.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		0.0f, 0.0f, 0.0f, L"��", L"΢���ź�", 13, DFontWeight::Bold);

	PlanViewB.Init({ 15, 50 }, { WindowWidth - 30, 350 }, { 255, 255, 255, 1.0f }, { 217, 217, 217, 1.0f }, 1.5f, 7.0f, 7.0f);

	PlanView.Init({ 15, 50 }, { WindowWidth - 30, 350 }, 0.0f, 70.0f, 200, true, true);

	PackMgr.Init({ 15, 433 }, { 115, 55 },
		{ { 230, 230, 230, 1.0f }, { 0, 0, 0, 0.0f }, { 70, 70, 70, 1.0f }, 200 },
		{ { 190, 190, 190, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 150 },
		{ { 130, 130, 130, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 50 },
		{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, 300 },
		7.0f, 7.0f, 0.0f, L"       ������", L"΢���ź�", 20, DFontWeight::Medium);

	PackImg.Init({ 17, 438 }, { 45, 45 }, false, DScaleMode::Fill, 0.95f);
	PackImg.LoadFromResource(IDB_PNG1, L"png", nullptr);

	NewPlan.Init({ 440, 439 }, { 135, 45 },
		{ { 230, 230, 230, 1.0f }, { 0, 0, 0, 0.0f }, { 70, 70, 70, 1.0f }, 200 },
		{ { 190, 190, 190, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 150 },
		{ { 130, 130, 130, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 50 },
		{ { 230, 230, 230, 1.0f }, { 0, 0, 0, 0.0f }, { 70, 70, 70, 1.0f }, 120 },
		7.0f, 7.0f, 0.0f, L"�½��ƻ�", L"΢���ź�", 20, DFontWeight::Medium);

	DelPlan.Init({ 585, 439 }, { 135, 45 },
		{ { 230, 230, 230, 1.0f }, { 0, 0, 0, 0.0f }, { 70, 70, 70, 1.0f }, 200 },
		{ { 190, 190, 190, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 150 },
		{ { 130, 130, 130, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 50 },
		{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, 300 },
		7.0f, 7.0f, 0.0f, L"ɾ���ƻ�", L"΢���ź�", 20, DFontWeight::Medium);

	//�����ڳ�ʼ��
	Main.Init(DConProc, 3.7f, 0.0f, true, 60);

	Main.AddControl(&TiB);
	Main.AddControl(&Ti, TiB, true);
	Main.AddControl(&Close, TiB);
	Main.AddControl(&MinSize, TiB);
	Main.AddControl(&PlanViewB);
	Main.AddControl(&PlanView, PlanViewB);
	Main.AddControl(&PackMgr);
	Main.AddControl(&PackImg, PackMgr, true);
	Main.AddControl(&NewPlan);
	Main.AddControl(&DelPlan);

	Main.CreateRenderThread();

	Main.Show();
	Main.SetShadowAlpha(0.4f, 200);

	return true;
}

//����DXUI�ؼ���Ϣ�Ļص�����
void __stdcall DConProc(HWND hWnd, UINT id, DControlType type, DControlMsg msg, WPARAM wParam, LPARAM lParam)
{
	if (hWnd == Main)
	{
		switch (msg)
		{
		case DControlMsg::Control_Click:
		{
			if (id == Close)//�رհ�ť������
			{
				Main.Release();

				planLock.Lock();
				std::map<UINT, PlanItem>::iterator it = plans.begin();
				while (it != plans.end())
				{
					it->second.Back->Release();
					it->second.Icon->Release();
					it->second.Name->Release();
					++it;
				}
				plans.clear();
				planLock.Unlock();
			}
			else if (id == MinSize)//��С����ť������
			{
				Main.Show(SW_MINIMIZE);
			}
			else if (id == PackMgr)
			{
				MgrWnd.Show(WndProc, Main);
			}
			else if (id == NewPlan)
			{
				AddPlan();
			}
			else if (id == DelPlan)
			{
				DeletePlan();
			}
			else if (type == DControlType::Button)//�б���ĳһ�ƻ�ɾ���������
			{
				planLock.Lock();
				std::map<UINT, PlanItem>::iterator planit = plans.find(id - 3);
				if (planit != plans.end())
				{
					float dstY = planit->second.Back->GetPositionY(true);
					planit->second.Back->SetSize(0.0f, 0.0f, 300, &b, 886);
					planit->second.Back->SetTotalOpacity(0.0f, 150);
					planit->second.Icon->SetTotalOpacity(0.0f, 170);
					planit->second.Name->SetTotalOpacity(0.0f, 150);
					
					++planit;
					for (UINT i = 0; planit != plans.end(); ++i)
					{
						planit->second.Back->SetPosition(22.0f, dstY + 67 * i, 300, &b);
						planit->second.Icon->SetPosition(25.0f, dstY + 67 * i + 8, 300, &b);
						planit->second.Name->SetPosition(75.0f, dstY + 67 * i + 15, 300, &b);
						planit->second.Del->SetPosition(650.0f, dstY + 67 * i + 15, 300, &b);
						++planit;
					}
				}
				planLock.Unlock();
			}
			break;
		}
		case DControlMsg::Control_StateChanged:
		{
			DControlState after = (DControlState)lParam;
			planLock.Lock();
			std::map<UINT, PlanItem>::iterator planit = plans.find(id);
			if (planit != plans.end() && DelPlan.GetText() != L"��  ��")
			{
				if (after == DControlState::MouseMove)
					planit->second.Back->SetFillColor({ 210, 210, 210, 1.0f }, 200);
				else if (after == DControlState::Normal)
					planit->second.Back->SetFillColor({ 237, 237, 237, 1.0f }, 200);
				else if (after == DControlState::Click)
					planit->second.Back->SetFillColor({ 180, 180, 180, 1.0f }, 100);
			}
			planLock.Unlock();
			break;
		}
		case DControlMsg::Control_EndOfAnimation:
		{
			if (wParam == 886)//�мƻ���ɾ��
			{
				planLock.Lock();
				std::map<UINT, PlanItem>::iterator planit = plans.find(id);
				if (planit != plans.end())
				{
					Main.DeleteControl((UINT)id + 3);
					Main.DeleteControl((UINT)id + 2);
					Main.DeleteControl((UINT)id + 1);
					Main.DeleteControl((UINT)id);
					delete planit->second.Back;
					delete planit->second.Icon;
					delete planit->second.Name;
					delete planit->second.Del;
					plans.erase(id);
					PlanView.SetFullHeight(67.0f * (float)plans.size() + PlanSpacing);
				}
				planLock.Unlock();
			}
			break;
		}
		}
	}
	return;
}
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//��DXUI������Ӧ����Ϣ�����ı�ؼ���״̬
	LRESULT res = Main.DXUIMessageProc(hWnd, message, wParam, lParam);
	LRESULT res1 = MgrWnd.MsgProc(hWnd, message, wParam, lParam);
	LRESULT res2 = EditWnd.MsgProc(hWnd, message, wParam, lParam);

	switch (message)
	{
	case WM_DESTROY:
		if (hWnd == Main)//����ǹ��ڴ��������ˣ��Ǿ��ͷŹ��ڴ��ڵ���
		{
			PostQuitMessage(0);
		}
		break;

	default:
		if (res != -1)
			return res;
		else if (res1 != -1)
			return res1;
		else if (res2 != -1)
			return res2;

		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}


void AddPlan()
{
	PlanItem plit;
	plit.Back = new DSolidColorBox;
	plit.Icon = new DImageBox;
	plit.Name = new DLabel;
	plit.Del = new DButton;

	if (!plit.Back || !plit.Icon || !plit.Name || !plit.Del)
		return;

	planLock.Lock();

	PlanFullHeight = 67.0f * (float)plans.size() + PlanSpacing;

	plit.Back->Init({ 22, 50 + (long)(PlanFullHeight) }, { 0, 0 }, { 237, 237, 237, 1.0f }, { 0, 0, 0, 0.0f }, 0.0f, 5.0f, 5.0f);
	plit.Icon->Init({ 25, 50 + (long)(PlanFullHeight)+8 }, { 44, 44 }, false, DScaleMode::Fill);
	plit.Icon->LoadFromResource(IDB_PNG2, L"png", nullptr);
	plit.Name->Init({ 75, 50 + (long)(PlanFullHeight)+15 }, { 200, 30 },
		{ { 50, 50, 50, 1.0f }, false, false, 0 },
		{ { 50, 50, 50, 1.0f }, false, false, 0 },
		{ { 50, 50, 50, 1.0f }, false, false, 0 },
		true, L"�ƻ�һ", L"΢���ź�", 20, false, DFontWeight::Medium, DAlignment::Near, DAlignment::Center);

	plit.Del->Init({ 650, 50 + (long)(PlanFullHeight)+15 }, { 0, 30 },
		{ { 255, 100, 70, 0.8f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 255, 70, 40, 1.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 200, 40, 20, 1.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 255, 83, 57, 0.8f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		15.0f, 15.0f, 0.0f, L"ɾ��", L"΢���ź�", 14, DFontWeight::Medium);

	//���Ӳ��붯��
	plit.Back->SetTotalOpacity(0.0f);
	plit.Icon->SetTotalOpacity(0.0f);
	plit.Name->SetTotalOpacity(0.0f);
	plit.Del->SetTotalOpacity(0.0f);

	plit.Back->SetTotalOpacity(1.0f, 150);
	plit.Icon->SetTotalOpacity(1.0f, 170);
	plit.Name->SetTotalOpacity(1.0f, 150);
	plit.Back->SetSize(WindowWidth - 44, 60.0f, 300, &b);

	Main.AddControl(plit.Back, PlanView);
	Main.AddControl(plit.Icon, plit.Back->GetID(), true);
	Main.AddControl(plit.Name, plit.Back->GetID(), true);
	Main.AddControl(plit.Del, plit.Back->GetID(), false);

	plans.insert(std::pair<UINT, PlanItem>(plit.Back->GetID(), plit));
	planLock.Unlock();
	PlanFullHeight += 60.0f;
	PlanView.SetFullHeight(PlanFullHeight + PlanSpacing);
	PlanView.SetScrollOffset(PlanView.GetFullHeight() - PlanView.GetHeight(), 300, &b);
	return;
}
void DeletePlan()
{
	planLock.Lock();
	if (DelPlan.GetText() == L"ɾ���ƻ�")
	{
		NewPlan.SetState(DControlState::Disable);
		NewPlan.SetTotalOpacity(0.0f, 150);
		DelPlan.SetText(L"��  ��");

		std::map<UINT, PlanItem>::iterator it = plans.begin();
		while (it != plans.end())
		{
			it->second.Del->SetTotalOpacity(1.0f, 150);
			it->second.Del->SetSize(55.0f, 30.0f, 350, &b);
			++it;
		}
	}
	else {
		NewPlan.SetState(DControlState::Normal);
		NewPlan.SetTotalOpacity(1.0f, 150);
		DelPlan.SetText(L"ɾ���ƻ�");

		std::map<UINT, PlanItem>::iterator it = plans.begin();
		while (it != plans.end())
		{
			it->second.Del->SetTotalOpacity(0.0f, 200);
			it->second.Del->SetSize(0.0f, 30.0f, 350, &b);
			++it;
		}
	}
	planLock.Unlock();
	return;
}
