#include "Main.h"

DWindow EditWnd;

DLinearColorBox EditTiB;
DLabel EditTi;
DButton EditClose;

DSolidColorBox ListB;

DTextBox TB_Words;
DTextBox TB_Des;

DButton EditFind;
DButton EditAdd;
DButton EditChange;
DButton EditDel;
DButton EditRet;

DScrollView WordView;
//�б����
typedef struct _tagWordItem
{
	DSolidColorBox* Back;
	DLabel* Word;
	std::wstring Des;
	bool Deleted;
}WordItem;

UINT NowChooseID = 0;
std::map<UINT, WordItem> words;
___DThreadLock wordLock;
float WordFullHeight = 0.0f;
#define WordSpacing 6.0f

//�����ڵĲ�������
#define Title       L"���༭"//�������ı�
#define WindowClass L"NoCiZhan Class"//����������
#define WindowWidth  795
#define WindowHeight 480

void __stdcall EditDConProc(HWND hWnd, UINT id, DControlType type, DControlMsg msg, WPARAM wParam, LPARAM lParam);
void SetChosenID(UINT id);//���õ�ǰѡ�еĵ�����Ҳ�չʾ�����Ϣ
void AddWord(std::wstring word, std::wstring des);//����һ������

bool PackEditUI::Show(WNDPROC Proc, HWND Parent)
{
	if (EditWnd.IsInit())
		return true;

	EditWnd.Parent = Parent;
	EditWnd.ExStyle = WS_EX_TOOLWINDOW;
	if (!EditWnd.Create(hInst, WindowClass, Title, Proc, WindowWidth, WindowHeight))
		return false;

	//ʹ�ò��裺��ʼ�������ؼ������� ���� �򴰿����ӿؼ� ���� ������Ⱦ�߳�

	DColorBox_Point p[2];
	p[0].color = { 0, 236, 116, 1.0f };
	p[0].position = 0.0f;
	p[1].color = { 0, 174, 247, 1.0f };
	p[1].position = 1.0f;

	EditTiB.Init({ 0, 0 }, { WindowWidth, 40 }, { 0, 0, 0, 0.0f }, p, 2, { 0, 40 }, { WindowWidth, 0 }, { 0 }, 0.0f, 0.0f, 0.0f, true);

	EditTi.Init({ 150, 0 }, { WindowWidth - 300, 40 },
		{ { 255, 255, 255, 1.0f }, false, false, 0 },
		{ { 255, 255, 255, 1.0f }, false, false, 0 },
		{ { 255, 255, 255, 1.0f }, false, false, 0 },
		true, Title, L"΢���ź�", 20, false, DFontWeight::Medium, DAlignment::Center, DAlignment::Center);

	EditClose.Init({ WindowWidth - 35, 0 }, { 35, 35 },
		{ { 255, 60, 40, 0.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 255, 70, 50, 0.8f }, { 200, 200, 200, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 150, 50, 30, 1.0f }, { 150, 150, 200, 0.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		0.0f, 0.0f, 0.0f, L"��", L"΢���ź�", 30, DFontWeight::Light);

	ListB.Init({ 15, 50 }, { 285, 415 }, { 250, 250, 250, 1.0f }, { 217, 217, 217, 1.0f }, 1.0f, 5.0f, 5.0f);

	WordView.Init({ 15, 50 }, { 285, 415 }, 0.0f, 50.0f, 200, true, false);

	TB_Words.Init({ 315, 50 }, { 460, 53 },
		{ {242, 242, 242, 1.0f }, { 191, 191, 191, 1.0f }, { 38, 38, 38, 1.0f }, 250 },
		{ {242, 242, 242, 1.0f }, {0, 180, 246, 1.0f}, { 38, 38, 38, 1.0f }, 250 },
		{ {250, 250, 250, 1.0f }, {0, 180, 246, 1.0f}, { 38, 38, 38, 1.0f }, 100 },
		{ {242, 242, 242, 1.0f }, {255, 255, 255, 1.0f}, {0, 0, 0, 1.0f}, 300 },
		7.0f, 7.0f, 1.0f, L"΢���ź�", 28, false, false, false, DFontWeight::DemiBold, DAlignment::Center, DAlignment::Center, { 0, 0, 0, 1.0f }, 1.5f, { 0, 0, 0, 0.3f });
	TB_Words.SetText(L"Words", false);

	TB_Des.Init({ 315, 110 }, { 460, 305 },
		{ {242, 242, 242, 1.0f }, { 191, 191, 191, 1.0f }, { 64, 64, 64, 1.0f }, 250 },
		{ {242, 242, 242, 1.0f }, {0, 180, 246, 1.0f}, { 64, 64, 64, 1.0f }, 250 },
		{ {250, 250, 250, 1.0f }, {0, 180, 246, 1.0f}, { 64, 64, 64, 1.0f }, 100 },
		{ {242, 242, 242, 1.0f }, {255, 255, 255, 1.0f}, {0, 0, 0, 1.0f}, 300 },
		7.0f, 7.0f, 1.0f, L"΢���ź�", 22, true, true, false, DFontWeight::Medium, DAlignment::Near, DAlignment::Near, { 0, 0, 0, 1.0f }, 1.5f, { 0, 0, 0, 0.3f });
	TB_Des.SetText(L"Descriptions", false);

	EditFind.Init({ 313, 422 }, { 90, 43 },
		{ { 230, 230, 230, 1.0f }, { 0, 0, 0, 0.0f }, { 64, 64, 64, 1.0f }, 200 },
		{ { 190, 190, 190, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 150 },
		{ { 130, 130, 130, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 50 },
		{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, 300 },
		7.0f, 7.0f, 0.0f, L"����", L"΢���ź�", 20);

	EditAdd.Init({ 407, 422 }, { 90, 43 },
		{ { 230, 230, 230, 1.0f }, { 0, 0, 0, 0.0f }, { 64, 64, 64, 1.0f }, 200 },
		{ { 190, 190, 190, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 150 },
		{ { 130, 130, 130, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 50 },
		{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, 300 },
		7.0f, 7.0f, 0.0f, L"����", L"΢���ź�", 20);

	EditChange.Init({ 501, 422 }, { 90, 43 },
		{ { 230, 230, 230, 1.0f }, { 0, 0, 0, 0.0f }, { 64, 64, 64, 1.0f }, 200 },
		{ { 190, 190, 190, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 150 },
		{ { 130, 130, 130, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 50 },
		{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, 300 },
		7.0f, 7.0f, 0.0f, L"�޸�", L"΢���ź�", 20);

	EditDel.Init({ 595, 422 }, { 90, 43 },
		{ { 230, 230, 230, 1.0f }, { 0, 0, 0, 0.0f }, { 64, 64, 64, 1.0f }, 200 },
		{ { 190, 190, 190, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 150 },
		{ { 130, 130, 130, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 50 },
		{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, 300 },
		7.0f, 7.0f, 0.0f, L"ɾ��", L"΢���ź�", 20);

	EditRet.Init({ 689, 422 }, { 90, 43 },
		{ { 230, 230, 230, 1.0f }, { 0, 0, 0, 0.0f }, { 64, 64, 64, 1.0f }, 200 },
		{ { 190, 190, 190, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 150 },
		{ { 130, 130, 130, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 50 },
		{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, 300 },
		7.0f, 7.0f, 0.0f, L"����", L"΢���ź�", 20);

	//�����ڳ�ʼ��
	EditWnd.Init(EditDConProc, 3.7f, 0.0f, true, 60);

	EditWnd.AddControl(&EditTiB);
	EditWnd.AddControl(&EditTi, EditTiB, true);
	EditWnd.AddControl(&EditClose, EditTiB);
	EditWnd.AddControl(&ListB);
	EditWnd.AddControl(&WordView, ListB);
	EditWnd.AddControl(&TB_Words);
	EditWnd.AddControl(&TB_Des);
	EditWnd.AddControl(&EditFind);
	EditWnd.AddControl(&EditAdd);
	EditWnd.AddControl(&EditChange);
	EditWnd.AddControl(&EditDel);
	EditWnd.AddControl(&EditRet);

	EditWnd.CreateRenderThread();

	EditWnd.Show();
	EditWnd.SetShadowAlpha(0.4f, 200);

	AddWord(TB_Words.GetText(), TB_Des.GetText());
	return true;
}

LRESULT CALLBACK PackEditUI::MsgProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	return EditWnd.DXUIMessageProc(hWnd, message, wParam, lParam);
}


void __stdcall EditDConProc(HWND hWnd, UINT id, DControlType type, DControlMsg msg, WPARAM wParam, LPARAM lParam)
{
	if (hWnd == EditWnd)
	{
		switch (msg)
		{
		case DControlMsg::Control_Click:
		{
			if (id == EditClose)
			{
				EditWnd.Release();

				wordLock.Lock();
				SetChosenID(0);

				std::map<UINT, WordItem>::iterator it = words.begin();
				while (it != words.end())
				{
					it->second.Back->Release();
					it->second.Word->Release();
					++it;
				}
				words.clear();
				wordLock.Unlock();
			}
			else if (id == EditAdd)
			{
				if (TB_Words.GetText() != L"" && TB_Des.GetText() != L"")
					AddWord(TB_Words.GetText(), TB_Des.GetText());
			}
			else if (id == EditChange)
			{
				wordLock.Lock();
				std::map<UINT, WordItem>::iterator wdit = words.find(NowChooseID);
				if (wdit != words.end())
				{
					wdit->second.Word->SetText(TB_Words.GetText());
					wdit->second.Des = TB_Des.GetText();
				}
				wordLock.Unlock();
			}
			else if (id == EditDel)
			{
				wordLock.Lock();
				std::map<UINT, WordItem>::iterator wdit = words.find(NowChooseID);
				if (wdit != words.end())
				{
					float dstY = wdit->second.Back->GetPositionY(true);
					wdit->second.Back->SetTotalOpacity(0.0f, 150);
					wdit->second.Word->SetTotalOpacity(0.0f, 170);
					wdit->second.Back->SetPosition(157, dstY, 300, &b);
					wdit->second.Back->SetSize(0.0f, 0.0f, 300, &b, 886);
					wdit->second.Deleted = true;

					std::map<UINT, WordItem>::iterator nwdit = wdit;
					UINT LastID = 0;
					do
						--nwdit;
					while (nwdit != words.end() && nwdit->second.Deleted);
					if (nwdit != words.end() && !nwdit->second.Deleted)
						LastID = nwdit->second.Back->GetID();
					else {
						nwdit = wdit;
						do
							++nwdit;
						while (nwdit != words.end() && nwdit->second.Deleted);
						if (nwdit != words.end() && !nwdit->second.Deleted)
							LastID = nwdit->second.Back->GetID();
					}
					SetChosenID(LastID);//ѡ����һ������

					++wdit;
					for (UINT i = 0; wdit != words.end();)
					{
						if (!wdit->second.Deleted)
						{
							wdit->second.Back->SetPosition(23.0f, dstY + 46 * i, 300, &b);
							wdit->second.Word->SetPosition(20.0f, dstY + 46 * i + 5, 300, &b);
							++i;
						}
						++wdit;
					}

				}
				wordLock.Unlock();
			}
			else if (type == DControlType::SolidColorBox)
			{
				wordLock.Lock();
				SetChosenID(id);
				wordLock.Unlock();
			}
			break;
		}
		case DControlMsg::Control_StateChanged:
		{
			DControlState after = (DControlState)lParam;
			wordLock.Lock();
			std::map<UINT, WordItem>::iterator wdit = words.find(id);
			if (wdit != words.end() && id != NowChooseID)
			{
				if (after == DControlState::MouseMove)
					wdit->second.Back->SetFillColor({ 180, 180, 180, 1.0f }, 200);
				else if (after == DControlState::Normal)
					wdit->second.Back->SetFillColor({ 220, 220, 220, 1.0f }, 300);
				else if (after == DControlState::Click)
					wdit->second.Back->SetFillColor({ 130, 130, 130, 1.0f }, 100);
			}
			wordLock.Unlock();
			break;
		}
		case DControlMsg::Control_EndOfAnimation:
		{
			if (wParam == 886)//�мƻ���ɾ��
			{
				wordLock.Lock();
				std::map<UINT, WordItem>::iterator wdit = words.find(id);
				if (wdit != words.end())
				{
					EditWnd.DeleteControl(id + 1);
					EditWnd.DeleteControl(id);
					delete wdit->second.Back;
					delete wdit->second.Word;
					words.erase(id);
					WordView.SetFullHeight(46.0f * (float)words.size() + WordSpacing);
				}
				wordLock.Unlock();
			}
			break;
		}

		}
	}
	return;
}
//Ҫ����������
void SetChosenID(UINT id)
{
	std::map<UINT, WordItem>::iterator wdit = words.find(id);
	if (wdit != words.end())
	{
		if (NowChooseID == 0)
		{
			NowChooseID = id;
			wdit->second.Back->SetFillColor({ 130, 130, 130, 1.0f }, 300);
			wdit->second.Word->SetTypeStyle(DControlState::Normal, { { 255, 255, 255, 1.0f }, false, false, 0 });
			TB_Words.SetText(wdit->second.Word->GetText());
			TB_Des.SetText(wdit->second.Des);
		}
		else {
			if (NowChooseID == id)
			{
				NowChooseID = 0;
				wdit->second.Back->SetFillColor({ 220, 220, 220, 1.0f }, 300);
				wdit->second.Word->SetTypeStyle(DControlState::Normal, { { 50, 50, 50, 1.0f }, false, false, 0 });
				TB_Words.SetText(L"");
				TB_Des.SetText(L"");
			}
			else {
				std::map<UINT, WordItem>::iterator Oldwdit = words.find(NowChooseID);
				NowChooseID = id;
				if (Oldwdit != words.end())
				{
					Oldwdit->second.Back->SetFillColor({ 220, 220, 220, 1.0f }, 300);
					Oldwdit->second.Word->SetTypeStyle(DControlState::Normal, { { 50, 50, 50, 1.0f }, false, false, 0 });
				}

				wdit->second.Back->SetFillColor({ 130, 130, 130, 1.0f }, 300);
				wdit->second.Word->SetTypeStyle(DControlState::Normal, { { 255, 255, 255, 1.0f }, false, false, 0 });
				TB_Words.SetText(wdit->second.Word->GetText());
				TB_Des.SetText(wdit->second.Des);
			}
		}
	}
	else if (id == 0)
	{
		std::map<UINT, WordItem>::iterator Oldwdit = words.find(NowChooseID);
		NowChooseID = 0;
		if (Oldwdit != words.end())
		{
			Oldwdit->second.Back->SetFillColor({ 220, 220, 220, 1.0f }, 300);
			Oldwdit->second.Word->SetTypeStyle(DControlState::Normal, { { 50, 50, 50, 1.0f }, false, false, 0 });
		}
		TB_Words.SetText(L"");
		TB_Des.SetText(L"");
	}
	return;
}

void AddWord(std::wstring word, std::wstring des)
{
	WordItem wdit;
	wdit.Back = new DSolidColorBox;
	wdit.Word = new DLabel;
	wdit.Des = des;
	wdit.Deleted = false;

	if (!wdit.Back || !wdit.Word)
		return;

	wordLock.Lock();

	WordFullHeight = 46.0f * (float)words.size() + WordSpacing;

	wdit.Back->Init({ 157, (long)(50.0f + WordFullHeight) }, { 0, 0 }, { 220, 220, 220, 1.0f }, { 0, 0, 0, 0.0f }, 0.0f, 5.0f, 5.0f);
	wdit.Word->Init({ 20, 50 + (long)(WordFullHeight)+5 }, { 275, 30 },
		{ { 50, 50, 50, 1.0f }, false, false, 0 },
		{ { 50, 50, 50, 1.0f }, false, false, 0 },
		{ { 50, 50, 50, 1.0f }, false, false, 0 },
		true, word, L"΢���ź�", 17, false, DFontWeight::Medium, DAlignment::Center, DAlignment::Center);

	//���Ӳ��붯��
	wdit.Back->SetTotalOpacity(0.0f);
	wdit.Word->SetTotalOpacity(0.0f);

	wdit.Back->SetTotalOpacity(1.0f, 150);
	wdit.Word->SetTotalOpacity(1.0f, 170);
	wdit.Back->SetPosition(23.0f, 50 + (long)(WordFullHeight), 300, &b);
	wdit.Back->SetSize(269.0f, 40.0f, 300, &b);

	EditWnd.AddControl(wdit.Back, WordView);
	EditWnd.AddControl(wdit.Word, wdit.Back->GetID(), true);

	words.insert(std::pair<UINT, WordItem>(wdit.Back->GetID(), wdit));
	WordFullHeight += 40.0f;
	WordView.SetFullHeight(WordFullHeight + WordSpacing);
	WordView.SetScrollOffset(WordView.GetFullHeight() - WordView.GetHeight(), 300, &b);

	SetChosenID(wdit.Back->GetID());
	wordLock.Unlock();
	return;
}