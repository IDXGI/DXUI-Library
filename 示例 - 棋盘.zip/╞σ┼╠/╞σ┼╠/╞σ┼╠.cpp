﻿#include "Main.h"

DWindow Main;
//主窗口部分
std::map<UINT, DImageBox*> mp;//这里UINT从1开始
DImageBox ib;//棋盘图片
DTextBox Msg;//调试信息文本框
DTextBox Arg;//参数信息文本框
DRadialColorBox TitleB;//标题栏底色
DLabel DXUI;//标题
DButton_WaterWave Close;//关闭按钮
DButton_WaterWave MinSize;//最小化按钮

DButton_WaterWave Fanzhuan;//反转棋盘按钮
DButton_WaterWave AIRed;//AI走红按钮
DButton_WaterWave AIBlack;//AI走黑按钮
DButton_WaterWave Back;//悔棋按钮
DButton_WaterWave Wan;//万能按钮

//主窗口的参数定义
#define Title          L"象棋 Artificial Intelligence"//标题栏文本
#define WindowWidth    950
#define WindowHeight   650
#define PanX           20
#define PanY           55
#define PanW           517
#define PanH           575
#define MsgX           PanX + PanW + 13
#define MsgY           PanY
#define MsgW           380
#define MsgH           480
#define BtnY           MsgY + MsgH + 10
//调用后端 DLL 函数定义
typedef void(*PCLICK)(int32_t, int32_t);
PCLICK pClick;
typedef int32_t(*PMAP)(int32_t, int32_t);
PMAP pGetMap;
typedef char* (*PINFO)();
PINFO pInfo;
typedef void (*PFAN)();
PFAN pFanzhuan;
typedef void (*PAI)(int32_t);
PAI pAI;
typedef void (*PBACK)();
PBACK pBack;
typedef void (*PWAN)(const char*);
PWAN pWan;


//运用组合控件设计进度条示例：
class MyProcessBar : public DCombinedCon
{
public:
	void MyInit(POINT pos, SIZE size, float radX, float radY)
	{
		UserNamedType = L"MyProcessBar";//在接收消息判断控件时，可以根据此名称判断

		X = (float)pos.x;
		Y = (float)pos.y;
		Width = (float)size.cx;
		Height = (float)size.cy;

		this->CursorStyle = LoadCursor(nullptr, IDC_HAND);
		this->Init(pos, size, radX, radY);//初始化当前组合控件
		Back.Init(pos, size, radX, radY, false, DScaleMode::Fill);
		Cut.Init(pos, size);
		Front.Init(pos, size, radX, radY, false, DScaleMode::Fill);
		Perc.Init(pos, size, { 255, 255, 255, 1.0f }, false, L"0.0 %", L"Microsoft YaHei UI", 13, false, DFontWeight::Medium, DAlignment::Center, DAlignment::Center);
		//添加到组合控件成为其组件，添加顺序影响遮盖关系
		this->AddComponent(&Back);
		this->AddComponent(&Cut);
		this->AddComponent(&Front, &Cut);//将Front以Cut的区域裁切
		this->AddComponent(&Perc);
		Back.LoadFromFile(L"Back.png");
		Front.LoadFromFile(L"Front.png");
		SetPercent(0.5f);
		return;
	}
	void SetPercent(float perc)
	{
		mUpdatePerc(perc);
	}
	float GetPercent(float perc) noexcept
	{
		return this->perc;
	}

private:
	DLabel Perc;//进度数字
	DImageBox Front;//顶图
	DClipRect Cut;//裁切区域
	DImageBox Back;//底图
	float X = 0.0f;
	float Y = 0.0f;
	float Width = 0.0f;
	float Height = 0.0f;
	float perc = 0.0f;

	void mUpdatePerc(float p)
	{
		this->perc = Min(Max(p, 0.0f), 1.0f);
		wchar_t s[30] = { 0 };
		swprintf_s(s, L"%.1f", perc * 100.0f);
		Perc.SetText(DString(s) + L" %");
		Cut.SetSize(Width * perc, Height, 300, &Bezier_Def);
	}
	//在每一帧时
	//【特别注意】：不要直接在里面进行控件更新操作，要增加条件判断。否则每一帧都会导致下一帧刷新，会造成该控件持续刷新。
	//不要在此函数内进行太耗时的操作，否则会影响此控件刷新时整个窗口的流畅度。可以设置某些控件的样式风格等，这些不太耗时。
	void On_Frame()
	{
		//实时刷新进度标签
		if (Cut.GetWidth() != Cut.GetWidth(true))//条件判断，只有在动画时才刷新
		{
			wchar_t s[30] = { 0 };
			swprintf_s(s, L"%.1f", Cut.GetWidth() / Width * 100.0f);
			Perc.SetText(DString(s) + L" %");
		}
	}
	//鼠标左键在此按下时
	void On_LMouseDown(int xPos, int yPos)//设备<独立>像素
	{
		mUpdatePerc((xPos - X) / Width);//更新控件百分比数据
	}
	//鼠标在此移动时
	void On_MouseMove(int xPos, int yPos)//设备<独立>像素
	{
		if (IsOnClick())//鼠标在按下时，即拖动时
		{
			mUpdatePerc((xPos - X) / Width);//更新控件百分比数据
		}
	}

};
MyProcessBar prc;

//程序函数
void __stdcall DConProc(HWND hWnd, UINT id, DControlType type, DString UserNamedType, DControlMsg msg, UINT Wnd_Msg, WPARAM Wnd_wParam, LPARAM Wnd_lParam);
bool Init();
void mGet();

int APIENTRY wWinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPWSTR lpCmdLine, _In_ int nCmdShow)
{
	//初始化
	if (!Init())
		return false;

	return (int)DXUI_MsgLoop();
}

bool Init()
{
	Main.hIcon = LoadIcon(Main.GetHInst(), MAKEINTRESOURCE(IDI_MY));
	Main.hIconSmall = LoadIcon(Main.GetHInst(), MAKEINTRESOURCE(IDI_SMALL));
	//创建窗口
	if (!Main.Create(Title, WindowWidth, WindowHeight))
		return false;

	//使用步骤：初始化各个控件及窗口 —— 向窗口添加控件 —— 创建渲染线程 —— 显示窗口
	DColorBox_Point p[3];

	p[0].color = { 255, 255, 255, 0.25f };
	p[0].position = 0.0f;
	p[1].color = { 255, 255, 255, 0.25f };
	p[1].position = 0.7f;
	p[2].color = { 255, 255, 255, 0.0f };
	p[2].position = 0.8f;
	//关闭按钮
	Close.Init({ WindowWidth - 35, 0 }, { 35, 35 }, 0.0f, 0.0f,
		{ { 255, 255, 255, 0.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 0.8f }, 250 },
		{ { 255, 255, 255, 0.25f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 255, 255, 255, 0.25f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 0 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		p, 200, 0.0f, L"✕", L"Microsoft YaHei UI", 18, DFontWeight::Normal);
	//最小化按钮
	MinSize.Init({ WindowWidth - 70, 0 }, { 35, 35 }, 0.0f, 0.0f,
		{ { 255, 255, 255, 0.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 0.8f }, 250 },
		{ { 255, 255, 255, 0.25f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 255, 255, 255, 0.25f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 0 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		p, 200, 0.0f, L"—", L"Microsoft YaHei UI", 13, DFontWeight::Bold);

	//顶部标题文字
	DXUI.Init({ WindowWidth / 2 - 200, 0 }, { 400, 35 }, { 255, 255, 255, 0.9f }, false, Title, L"Microsoft YaHei UI", 20, false, DFontWeight::Medium, DAlignment::Center, DAlignment::Center);

	//顶部渐变标题栏背景
	p[0].color = { 21, 183, 255, 1.0f };
	p[0].position = 0.0f;
	p[1].color = { 180, 31, 255, 1.0f };
	p[1].position = 1.0f;
	TitleB.Init({ 0, 0 }, { WindowWidth, 35 }, 0.0f, 0.0f, { 0, 0, 0, 0.0f }, p, 2, { WindowWidth / 2, 17 }, WindowWidth / 2.0f, WindowHeight / 2.0f, { 0 }, 0.0f, true);

	//棋盘
	ib.Init({ PanX, PanY }, { PanW, PanH }, 5.0f, 5.0f, false, DScaleMode::Fill);
	ib.LoadFromResource(IDR_IMG1, L"img", nullptr);
	//状态信息文本框
	Msg.Init({ MsgX, MsgY }, { MsgW, MsgH }, 5.0f, 5.0f,
		{ {0, 0, 0, 0.05f}, {0, 122, 204, 0.3f}, {0, 0, 0, 0.8f}, 200 },
		{ {0, 0, 0, 0.02f}, {0, 122, 204, 0.6f}, {0, 0, 0, 1.0f}, 200 },
		{ {0, 0, 0, 0.0f}, {0, 122, 204, 1.0f}, {0, 0, 0, 1.0f}, 100 },
		{ {0, 0, 0, 0.0f}, {0, 0, 0, 0.0f}, {255, 255, 255, 1.0f}, 300 },
		2.0f, L"Microsoft YaHei UI", 18, true, true, false, DFontWeight::Normal, DAlignment::Near, DAlignment::Near);

	p[0].color = { 0, 0, 0, 0.25f };
	p[0].position = 0.0f;
	p[1].color = { 0, 0, 0, 0.25f };
	p[1].position = 0.7f;
	p[2].color = { 0, 0, 0, 0.0f };
	p[2].position = 0.8f;

	//反转棋盘
	Fanzhuan.Init({ MsgX, BtnY }, { 90, 40 }, 20.0f, 20.0f,
		{ { 0, 0, 0, 0.1f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 250 },
		{ { 0, 0, 0, 0.25f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 250 },
		{ { 0, 0, 0, 0.25f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 0 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		p, 350, 0.0f, L"反转棋盘", L"Microsoft YaHei UI", 17);
	//AI走红
	AIRed.Init({ MsgX + 97, BtnY }, { 90, 40 }, 20.0f, 20.0f,
		{ { 0, 0, 0, 0.1f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 250 },
		{ { 0, 0, 0, 0.25f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 250 },
		{ { 0, 0, 0, 0.25f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 0 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		p, 350, 0.0f, L"AI 走红", L"Microsoft YaHei UI", 17);
	//AI走黑
	AIBlack.Init({ MsgX + 194, BtnY }, { 90, 40 }, 20.0f, 20.0f,
		{ { 0, 0, 0, 0.1f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 250 },
		{ { 0, 0, 0, 0.25f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 250 },
		{ { 0, 0, 0, 0.25f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 0 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		p, 350, 0.0f, L"AI 走黑", L"Microsoft YaHei UI", 17);
	//悔棋
	Back.Init({ MsgX + 290, BtnY }, { 90, 40 }, 20.0f, 20.0f,
		{ { 0, 0, 0, 0.1f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 250 },
		{ { 0, 0, 0, 0.25f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 250 },
		{ { 0, 0, 0, 0.25f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 0 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		p, 350, 0.0f, L"悔   棋", L"Microsoft YaHei UI", 17);

	//万能按钮
	Wan.Init({ MsgX + 290, BtnY + 48 }, { 90, 35 }, 5.0f, 5.0f,
		{ { 0, 0, 0, 0.1f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 250 },
		{ { 0, 0, 0, 0.25f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 250 },
		{ { 0, 0, 0, 0.25f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 0 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		p, 350, 0.0f, L"万能按钮", L"Microsoft YaHei UI", 16);

	//参数信息文本框
	Arg.Init({ MsgX, BtnY + 48 }, { 284, 35 }, 5.0f, 5.0f,
		{ {0, 0, 0, 0.05f}, {0, 122, 204, 0.3f}, {0, 0, 0, 0.8f}, 200 },
		{ {0, 0, 0, 0.02f}, {0, 122, 204, 0.6f}, {0, 0, 0, 1.0f}, 200 },
		{ {0, 0, 0, 0.0f}, {0, 122, 204, 1.0f}, {0, 0, 0, 1.0f}, 100 },
		{ {0, 0, 0, 0.0f}, {0, 0, 0, 0.0f}, {255, 255, 255, 1.0f}, 300 },
		1.5f, L"Microsoft YaHei UI", 16, false, false, false, DFontWeight::Normal, DAlignment::Near, DAlignment::Center);

	prc.MyInit({ 50, 37 }, { 250, 12 }, 6.0f, 6.0f);//自定义进度条
	//主窗口初始化
	Main.Init(DConProc);
	//添加控件
	Main.AddControl(&TitleB);
	Main.AddControl(&DXUI, TitleB, true);
	Main.AddControl(&Close, TitleB);
	Main.AddControl(&MinSize, TitleB);
	Main.AddControl(&ib);
	Main.AddControl(&Msg);
	Main.AddControl(&Fanzhuan);
	Main.AddControl(&AIRed);
	Main.AddControl(&AIBlack);
	Main.AddControl(&Back);
	Main.AddControl(&Wan);
	Main.AddControl(&Arg);
	Main.AddControl(&prc);
	//创建渲染线程，所有控件开始绘制
	Main.CreateRenderThread();
	//显示窗口
	Main.Show();

	//导入后端 DLL
	HINSTANCE hInstDLL = LoadLibraryW(L"AI.dll");
	if (hInstDLL)
	{
		pClick = (PCLICK)GetProcAddress(hInstDLL, "click");
		pGetMap = (PMAP)GetProcAddress(hInstDLL, "get_map");
		pInfo = (PINFO)GetProcAddress(hInstDLL, "get_debug_info");
		pFanzhuan = (PFAN)GetProcAddress(hInstDLL, "fan_zhuan");
		pAI = (PAI)GetProcAddress(hInstDLL, "AI_move");
		pBack = (PBACK)GetProcAddress(hInstDLL, "back");
		pWan = (PWAN)GetProcAddress(hInstDLL, "wan_neng_func");
	}
	if (!pClick || !pGetMap || !pInfo || !pFanzhuan || !pAI || !pBack || !pWan)
		MessageBoxW(Main, L"DLL 加载出错", L"[ 象棋 ERROR ]", MB_OK | MB_ICONERROR);
	//创建棋子控件map
	POINT pos = { PanX + 9, PanY + 6 };
	DImageBox* b = nullptr;
	for (UINT i = 0, n = 0; i < 10; ++i)
	{
		for (UINT j = 0; j < 9; ++j)
		{
			++n;
			b = new DImageBox;
			b->Init({ pos.x, pos.y }, { 53, 53 }, 26.5f, 26.5f, false, DScaleMode::Fill, 1.0f, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, 5.0f);
			b->CursorStyle = LoadCursorW(nullptr, IDC_HAND);//设置手形光标
			b->UserNamedType = L"QiZi";//设置一个自定义类型，方便接收消息时查找
			mp.insert(std::pair<UINT, DImageBox*>(n, b));
			Main.AddControl(b, ib);
			pos.x += 56;
		}
		pos.x = PanX + 9;
		pos.y += 56;
		if (i == 4)
			pos.y += 5;
	}
	mGet();
	Msg.SetText(L"此程序后端实现尚未完善，仅用于界面展示。");
	return true;
}

void __stdcall DConProc(HWND hWnd, UINT id, DControlType type, DString UserNamedType, DControlMsg msg, UINT Wnd_Msg, WPARAM Wnd_wParam, LPARAM Wnd_lParam)
{
	switch (msg)//分辨消息，并比较ID判断
	{
	case DControlMsg::Control_Click://这里响应的按钮的按下操作
	{
		if (id == Close)
		{
			Main.Release();
			PostQuitMessage(0);
		}
		else if (id == MinSize)
		{
			Main.Show(SW_SHOWMINIMIZED);
		}
		else if (UserNamedType == L"QiZi")
		{
			//计算出横纵坐标
			int32_t n = id - *(mp.begin()->second) + 1;
			int32_t x = -1, y = 0;
			while ((y + 1) * 9 < n && y < 10)
				++y;
			x = n - y * 9 - 1;
			if (x >= 0 && y >= 0 && x <= 8 && y <= 9)
			{
				pClick(y, x);//点击 (由于此处前端作者与后端作者建系反了，所以反着传值)
				mGet();
			}
		}
		else if (id == Fanzhuan)
		{
			pFanzhuan();
			mGet();
		}
		else if (id == AIRed)
		{
			pAI(1);
			mGet();
		}
		else if (id == AIBlack)
		{
			pAI(0);
			mGet();
		}
		else if (id == Back)
		{
			pBack();
			mGet();
		}
		else if (id == Wan)
		{
			DString arg = Arg.GetText();
			pWan(arg.c_strA());
			mGet();
		}
		break;
	}
	case DControlMsg::Control_StateChanged:
	{
		DControlState after = (DControlState)Wnd_lParam;
		if (UserNamedType == L"QiZi")
		{
			DImageBox* b = mp.at(id - *(mp.begin()->second) + 1);
			if (after == DControlState::MouseMove)
			{
				b->SetBackColor({ 0, 0, 0, 0.25f }, 150);
				b->SetTotalOpacity(1.0f, 50);
			}
			else if (after == DControlState::Normal)
			{
				b->SetBackColor({ 0, 0, 0, 0.0f }, 150);
				b->SetTotalOpacity(1.0f, 50);
			}
			else if (after == DControlState::Click)
			{
				b->SetBackColor({ 0, 0, 0, 0.4f }, 50);
				b->SetTotalOpacity(0.6f, 50);
			}
		}
		break;
	}
	}
	return;
}

void mGet()
{
	for (UINT i = 0, n = 0; i < 10; ++i)
	{
		for (UINT j = 0; j < 9; ++j)
		{
			++n;
			int32_t r = pGetMap(i, j);//获取棋盘信息
			int32_t baohu = r & 1;
			int32_t zy = r >> 1 & 1;
			int32_t st = r >> 2 & 3;
			int32_t T = r >> 4;

			DImageBox* b = mp.at(n);
			
			if (st == 1)
				b->SetStrokeColor({ 255, 30, 30, 0.8f }, 100);//红色
			else if(st == 2)
				b->SetStrokeColor({ 30, 30, 255, 0.8f }, 100);//蓝色
			else if (st == 3)
				b->SetStrokeColor({ 30, 255, 30, 0.8f }, 100);//绿色
			else
				b->SetStrokeColor({ 30, 255, 30, 0.0f }, 100);//绿色

			float opa = baohu ? 0.6f : 1.0f;
			if (T >= 0 && T <= 6)
			{
				b->SetBackgroundGaussianBlur(1.0f);//设置背景高斯模糊
				b->SetImageOpacity(opa, 150);//设置图片不透明度
			}
			else if (T == 7)
			{
				b->SetBackgroundGaussianBlur(0.0f);//设置背景高斯模糊
				b->SetImageOpacity(0.0f, 150);//设置图片不透明度
			}
			switch (T)
			{
			case 0:
				b->LoadFromResource(zy == 0 ? IDB_PNG9 : IDB_PNG6, L"PNG");
				break;
			case 1:
				b->LoadFromResource(zy == 0 ? IDB_PNG12 : IDB_PNG5, L"PNG");
				break;
			case 2:
				b->LoadFromResource(zy == 0 ? IDB_PNG13 : IDB_PNG7, L"PNG");
				break;
			case 3:
				b->LoadFromResource(zy == 0 ? IDB_PNG8 : IDB_PNG2, L"PNG");
				break;
			case 4:
				b->LoadFromResource(zy == 0 ? IDB_PNG10 : IDB_PNG3, L"PNG");
				break;
			case 5:
				b->LoadFromResource(zy == 0 ? IDB_PNG11 : IDB_PNG4, L"PNG");
				break;
			case 6:
				b->LoadFromResource(zy == 0 ? IDB_PNG14 : IDB_PNG1, L"PNG");
				break;
			default:
				break;
			}
		}
	}
	char* msg = pInfo();//获取调试信息
	Msg.SetText(msg);
	return;
}
