﻿#pragma once

#include <SDKDDKVer.h>
#define WIN32_LEAN_AND_MEAN//从Windows头文件中排除极少使用的内容
//Windows头文件
#include <Windows.h>
#include <stdint.h>
#include "Resource.h"//程序资源文件
/**********DXUI界面库************/
#include "DXUI_Library.h"
