﻿#include "Main.h"

//主窗口的参数定义
#define WindowWidth  350
#define WindowHeight 300
DButton CliClose;
DButton CliMinSize;
DImageBox BackImg;
DImageBox Logo;
DLabel lb1;
DLabel lb2;
DLabel lb3;
DLabel lb4;

DTextBox Delay;
DButton Begin;
DButton End;

#define SleepInterval 50
void __cdecl ClickThread(void* param);
bool ThreadAlive = false;
bool ExitThreadFlag = false;
ATOM HotKeyBegin;
ATOM HotKeyStop;

bool ClickInit()
{
	CliClose.Init({ CliOfsX + WindowWidth - 35, CliOfsY}, { 35, 35 },
		{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 300 },
		{ { 255, 70, 50, 0.8f }, { 200, 200, 200, 0.0f }, { 0, 0, 0, 1.0f }, 300 },
		{ { 150, 50, 30, 1.0f }, { 150, 150, 200, 0.0f }, { 0, 0, 0, 1.0f }, 50 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		0.0f, 0.0f, 0.0f, L"✕", L"微软雅黑", 18, DFontWeight::Normal);

	CliMinSize.Init({ CliOfsX + WindowWidth - 70, CliOfsY}, { 35, 35 },
		{ { 0, 0, 0, 0.0f }, { 26, 217, 110, 0.0f }, { 0, 0, 0, 1.0f }, 300 },
		{ { 128, 128, 128, 0.6f }, { 35, 231, 131, 0.0f }, { 0, 0, 0, 1.0f }, 300 },
		{ { 128, 128, 128, 0.8f }, { 31, 207, 108, 1.0f }, { 0, 0, 0, 1.0f }, 50 },
		{ { 128, 128, 128, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		0.0f, 0.0f, 0.0f, L"—", L"微软雅黑", 13, DFontWeight::Bold);

	BackImg.Init({ CliOfsX, CliOfsY }, { WindowWidth, WindowHeight }, false, DScaleMode::Fill, 1.0f, { 255, 255, 255, 0.9f });
	BackImg.LoadFromResource(PIC_CLICKB, L"png", nullptr);
	Logo.Init({ CliOfsX + 5, CliOfsY + 7 }, { 50, 14 }, false, DScaleMode::EqualScale);
	Logo.LoadFromResource(PIC_DXUI, L"png", nullptr);

	lb1.Init({ CliOfsX + WindowWidth / 2 - 75, CliOfsY + 20 }, { 150, 50 },
		{ { 0, 137, 255, 1.0f }, false, false, 0 },
		{ { 0, 137, 255, 1.0f }, false, false, 0 },
		{ { 0, 137, 255, 1.0f }, false, false, 0 },
		true, L"鼠标连点器", L"微软雅黑", 30, false, DFontWeight::Normal, DAlignment::Center, DAlignment::Center);

	lb2.Init({ CliOfsX + 20, CliOfsY + 100 }, { 95, 30 },
		{ { 0, 0, 0, 1.0f }, false, false, 0 },
		{ { 0, 0, 0, 1.0f }, false, false, 0 },
		{ { 0, 0, 0, 1.0f }, false, false, 0 },
		true, L"点击间隔 :", L"微软雅黑", 20, false, DFontWeight::Normal, DAlignment::Far, DAlignment::Center);

	lb3.Init({ CliOfsX + 280, CliOfsY + 100 }, { 30, 30 },
		{ { 0, 0, 0, 1.0f }, false, false, 0 },
		{ { 0, 0, 0, 1.0f }, false, false, 0 },
		{ { 0, 0, 0, 1.0f }, false, false, 0 },
		true, L"ms", L"微软雅黑", 20, false, DFontWeight::Normal, DAlignment::Near, DAlignment::Center);

	lb4.Init({ CliOfsX - 285, CliOfsY + WindowHeight - 71 }, { 280, 20 },
		{ { 50, 50, 50, 1.0f }, false, false, 0 },
		{ { 50, 50, 50, 1.0f }, false, false, 0 },
		{ { 50, 50, 50, 1.0f }, false, false, 0 },
		true, L"", L"微软雅黑", 13, false, DFontWeight::Normal, DAlignment::Near, DAlignment::Center);

	Delay.Init({ CliOfsX + 120, CliOfsY + 100 }, { 150, 30 },
		{ {0, 0, 0, 0.1f }, { 160, 160, 160, 0.8f }, { 0, 0, 0, 1.0f }, 250 },
		{ {0, 0, 0, 0.2f }, { 120, 120, 120, 0.8f }, { 0, 0, 0, 1.0f }, 250 },
		{ {0, 0, 0, 0.05f }, { 80, 80, 80, 1.0f }, { 0, 0, 0, 1.0f }, 150 },
		{ {0, 0, 0, 0.3f }, { 0, 0, 0, 0.2f }, {0, 0, 0, 1.0f}, 150 },
		1.5f, 1.5f, 1.5f, L"微软雅黑", 15, false, false, false, DFontWeight::Bold, DAlignment::Near, DAlignment::Center, { 0, 0, 0, 1.0f }, 1.5f, { 0, 0, 0, 0.3f });
	Delay.SetText(L"10");

	Begin.Init({ CliOfsX, CliOfsY + WindowHeight - 50 }, { 175, 50 },
		{ { 0, 0, 0, 0.1f }, { 26, 217, 110, 0.0f }, { 0, 0, 0, 1.0f }, 300 },
		{ { 0, 0, 0, 0.3f }, { 35, 231, 131, 0.0f }, { 0, 0, 0, 1.0f }, 250 },
		{ { 0, 0, 0, 0.5f }, { 31, 207, 108, 1.0f }, { 0, 0, 0, 1.0f }, 50 },
		{ { 0, 0, 0, 0.1f }, { 26, 217, 110, 0.0f }, { 128, 128, 128, 1.0f }, 150 },
		0.0f, 0.0f, 0.0f, L"开始(F2)", L"微软雅黑", 20, DFontWeight::Normal);

	End.Init({ CliOfsX + 175, CliOfsY + WindowHeight - 50 }, { 175, 50 },
		{ { 0, 0, 0, 0.1f }, { 26, 217, 110, 0.0f }, { 0, 0, 0, 1.0f }, 300 },
		{ { 0, 0, 0, 0.3f }, { 35, 231, 131, 0.0f }, { 0, 0, 0, 1.0f }, 250 },
		{ { 0, 0, 0, 0.5f }, { 31, 207, 108, 1.0f }, { 0, 0, 0, 1.0f }, 50 },
		{ { 0, 0, 0, 0.1f }, { 26, 217, 110, 0.0f }, { 128, 128, 128, 1.0f }, 150 },
		0.0f, 0.0f, 0.0f, L"停止(F3)", L"微软雅黑", 20, DFontWeight::Normal);
	End.SetState(DControlState::Disable);
	//添加控件，控件遮盖关系以添加的顺序为依据
	//如果想让某控件的背景为另一个控件，则必须添加背景控件为该控件的Parent，那该控件叫做背景控件的Child
	//Child控件不能超出Parent控件，超出后会以Parent控件的边缘裁剪
	Main.AddControl(&BackImg, sw);
	Main.AddControl(&Logo, BackImg);
	Main.AddControl(&CliClose, BackImg);
	Main.AddControl(&CliMinSize, BackImg);
	Main.AddControl(&lb1, BackImg);
	Main.AddControl(&lb2, BackImg);
	Main.AddControl(&lb3, BackImg);
	Main.AddControl(&lb4, BackImg);
	Main.AddControl(&Delay, BackImg);
	Main.AddControl(&Begin, BackImg);
	Main.AddControl(&End, BackImg);

	HotKeyBegin = GlobalAddAtomW(L"ClickBegin") - 0xC000;
	HotKeyStop = GlobalAddAtomW(L"ClickStop") - 0xC000;
	RegisterHotKey(Main, HotKeyBegin, 0, VK_F2);
	RegisterHotKey(Main, HotKeyStop, 0, VK_F3);
	return true;
}

void __stdcall ClickDConProc(HWND hWnd, UINT id, DControlType type, DControlMsg msg, WPARAM wParam, LPARAM lParam)
{
	if (hWnd == Main)
	{
		if (msg == DControlMsg::Control_Click)//多窗口时的分辨处理
		{
			if (id == Begin)
				BeginClick();
			else if (id == End)
				StopClick();
		}
	}
	return;
}

void BeginClick()
{
	if (!ThreadAlive)
		_beginthread(ClickThread, 0, nullptr);
	return;
}
void StopClick()
{
	if (ThreadAlive)
	{
		ExitThreadFlag = true;
		while (ThreadAlive)
		{
			Sleep(SleepInterval);
		}
	}
	Main.Show();
	return;
}
void __cdecl ClickThread(void* param)
{
	if (ThreadAlive)
		return;

	ThreadAlive = true;
	ExitThreadFlag = false;

	long delay = 10;
	long ClickedCount = 0;

	delay = _wtol(Delay.GetText().c_str());
	if (delay < 0)
		delay = 0;

	//将文本框内容设为计算后的值
	wchar_t* wstr = new wchar_t[128];
	_ltow_s(delay, wstr, 128, 10);
	Delay.SetState(DControlState::Disable);
	Delay.ExitSelectMode();
	Delay.SetText(wstr);
	delete[] wstr;

	Begin.SetState(DControlState::Disable);
	End.SetState(DControlState::Normal);
	lb4.SetText(L"已点击 0 次 (无法停止请用快捷键)");
	lb4.SetPosition(CliOfsX + 5, CliOfsY + WindowHeight - 71, 1200, &b);

	POINT P = { 0 };
	bool succ = timeBeginPeriod(1);
	wchar_t* buf = new wchar_t[100];
	while (!ExitThreadFlag)
	{
		if (Logo.GetTotalOpacity() > 0.99f)
			Logo.SetTotalOpacity(0.1f, 600);
		else if(Logo.GetTotalOpacity() < 0.11f)
			Logo.SetTotalOpacity(1.0f, 600);

		GetCursorPos(&P);
		mouse_event(MOUSEEVENTF_LEFTDOWN, P.x, P.y, 0, 0);
		mouse_event(MOUSEEVENTF_LEFTUP, P.x, P.y, 0, 0);
		
		//更新点击次数
		ClickedCount++;
		swprintf_s(buf, 100, L"已点击 %d 次 (无法停止请用快捷键)", ClickedCount);
		lb4.SetText(buf);

		if (delay <= SleepInterval)
		{
			Sleep(delay);
		}
		else {
			long restDelay = delay;
			while (restDelay > SleepInterval && !ExitThreadFlag)
			{
				Sleep(SleepInterval);
				restDelay -= SleepInterval;
			}
			if (restDelay > 0 && !ExitThreadFlag)
				Sleep(restDelay);
		}
	}
	if (succ)
		timeEndPeriod(1);

	Logo.SetTotalOpacity(1.0f, 1);

	lb4.SetPosition(CliOfsX - 285, CliOfsY + WindowHeight - 71, 350, nullptr);

	Delay.SetState(DControlState::Normal);
	End.SetState(DControlState::Disable);
	Begin.SetState(DControlState::Normal);
	ExitThreadFlag = false;
	ThreadAlive = false;
	return;
}
