﻿//DXUI 示例程序 - ChatUI部分
#include "Main.h"

//控件定义
DSolidColorBox LoginBack;//背景
DLabel Ti;//标题
DLinearColorBox TiB;//标题背景
DButton Close;//关闭按钮
DButton Mini;//最小化按钮
DButton Regi;//转到注册状态按钮
DButton Abou;//更多按钮
DLinearColorBox MainBtn;//主窗口按钮的背景
DLabel TBtn;//主窗口按钮的文字
DTextBox Account;//用户名或口令的文本框
DLabel Acc;//文本框为空时来显示的文字
DSolidColorBox MainErr;//错误提示时的红点
DLabel MainErrMsg;//错误提示的信息文字

//////////更多部分控件
DButton Ret;//返回按钮
DLabel Vers;//版本文字
DButton Update;//更新按钮
DTextBox Proxy;//代理服务器文本框
DLabel Prox;//代理服务器文本框为空时的文字
DLabel UpdMsg;//更新完成后提示的信息

/////////注册口令弹窗
#define PopupWidth  320
#define PopupHeight 200
#define PopupAniTime 200//窗口渐显渐隐的时长
DWindow KeyPopup;//口令弹窗窗口（透明窗口）
DLinearColorBox BackGro;//背景颜色
DTextBox Comm;//口令信息
DButton CommOK;//确定键

/////////聊天界面
#define ChatWidth  450
#define ChatHeight 600
#define NewMsgAniTime 500
DWindow Chat;//聊天的窗口
DButton CClose;//关闭键
DButton CMini;//最小化键
DButton CRet;//注销键
DLabel CTi;//窗口标题，即用户名
DLinearColorBox CTiB;//窗口标题背景
DTextBox Content;//显示消息记录的文本框
DTextBox Send;//发送区的文本框
DLabel TSen;//文本框为空时的提示
DLinearColorBox SendBtn;//发送键的背景
DLabel TSendBtn;//发送键的文字

//主窗口的参数定义
#define TitleHeight 40
#define WindowWidth  350
#define WindowHeight 230
#define MainAniTime 800

UINT_PTR ErrTimer = 0;
UINT_PTR UpdMsgTimer = 0;

UINT page = 1;//0=注册，1=登录，2=关于

void Login();//登录键被点击
void Register();//注册键被点击
void UpdateClick();//更新键被点击
void SendClick();//发送键被点击

void SetPage(UINT Page);//登录窗口的动画，不必理会
void MainErrorMsg(const wchar_t* Text, bool hide);//登录、注册界面显示错误信息
void UpdateMsg(std::wstring Text, bool hide);//更新部分的消息提示(failed,successfully等)
void CommandPopup(std::wstring Text);//口令的弹窗
void LoginMode();//切换到登录模式
void ChatMode(std::wstring UserName);//切换到聊天模式

//程序入口
void InitChatUI()
{
	LoginBack.Init({ ChatUIOfsX, ChatUIOfsY }, { WindowWidth, WindowHeight }, { 255, 255, 255, 0.9f });
	Close.Init({ ChatUIOfsX + WindowWidth - 35, ChatUIOfsY }, { 35, 35 },
		{ { 255, 60, 40, 0.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 0.8f }, 250 },
		{ { 255, 70, 50, 1.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 150, 50, 30, 1.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		0.0f, 0.0f, 0.0f, L"✕", L"微软雅黑", 18, DFontWeight::Normal);

	Mini.Init({ ChatUIOfsX + WindowWidth - 70, ChatUIOfsY }, { 35, 35 },
		{ { 255, 255, 255, 0.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 0.8f }, 250 },
		{ { 255, 255, 255, 0.3f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 255, 255, 255, 0.5f }, { 0, 0, 0, 1.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		0.0f, 0.0f, 0.0f, L"—", L"微软雅黑", 13, DFontWeight::Bold);

	DColorBox_Point p[2];
	p[0].color = { 23, 181, 255, 1.0f };
	p[0].position = 0.0f;
	p[1].color = { 180, 31, 255, 1.0f };
	p[1].position = 1.0f;

	TiB.Init({ ChatUIOfsX, ChatUIOfsY }, { WindowWidth, TitleHeight }, { 0, 0, 0, 0.0f }, p, 2, { ChatUIOfsX, ChatUIOfsY + TitleHeight / 2 }, { ChatUIOfsX + WindowWidth, ChatUIOfsY + TitleHeight / 2 }, { 0 }, 0.0f, 0.0f, 0.0f, true);

	Ti.Init({ ChatUIOfsX + 120, ChatUIOfsY }, { WindowWidth - 240, TitleHeight }, { 255, 255, 255, 1.0f }, true, L"ChatUI", L"微软雅黑", 18, false, DFontWeight::Normal, DAlignment::Center, DAlignment::Center);

	Account.Init({ ChatUIOfsX + 60, ChatUIOfsY + 88 }, { 230, 32 },
		{ {0, 0, 0, 0.1f }, { 23, 181, 255, 0.1f }, { 0, 0, 0, 1.0f }, 250 },
		{ {0, 0, 0, 0.25f }, { 23, 181, 255, 0.3f }, { 0, 0, 0, 1.0f }, 250 },
		{ {0, 0, 0, 0.15f }, { 23, 181, 255, 0.3f }, { 0, 0, 0, 1.0f }, 150 },
		{ {0, 0, 0, 0.2f }, {0, 0, 0, 0.0f}, {0, 0, 0, 1.0f}, 200 },
		3.0f, 3.0f, 2.0f, L"微软雅黑", 16, false, false, false, DFontWeight::Bold, DAlignment::Near, DAlignment::Center, { 0, 0, 0, 1.0f }, 1.5f, { 0, 0, 0, 0.2f });

	Acc.Init({ ChatUIOfsX + 65, ChatUIOfsY + 88 }, { 230, 32 }, { 0, 0, 0, 0.3f }, true, L"口令", L"微软雅黑", 15, false, DFontWeight::Normal, DAlignment::Near, DAlignment::Center);

	p[0].color = { 23, 181, 255, 1.0f };
	p[0].position = 0.0f;
	p[1].color = { 180, 31, 255, 1.0f };
	p[1].position = 1.0f;

	MainBtn.Init({ ChatUIOfsX + 50, ChatUIOfsY + 170 }, { 250, 35 }, { 0, 0, 0, 1.0f }, p, 2, { ChatUIOfsX + 50, ChatUIOfsY + 187 }, { ChatUIOfsX + 300, ChatUIOfsY + 187 }, { 0 }, 0.0f, 17.5f, 17.5f);

	TBtn.Init({ ChatUIOfsX + 130, ChatUIOfsY + 170 }, { 90, 35 }, { 255, 255, 255, 1.0f }, true, L"登录", L"微软雅黑", 17, false, DFontWeight::Normal, DAlignment::Center, DAlignment::Center);

	MainErr.Init({ ChatUIOfsX + 55, ChatUIOfsY + 139 }, { 15, 15 }, { 229, 87, 76, 1.0f }, { 0 }, 0.0f, 7.5f, 7.5f, true);
	MainErrMsg.Init({ ChatUIOfsX + 73, ChatUIOfsY + 134 }, { 250, 25 },
		{ { 0, 0, 0, 0.7f }, false, false, 0 },
		{ { 0, 0, 0, 0.7f }, false, false, 0 },
		{ { 0, 0, 0, 0.7f }, false, false, 0 },
		true, L"", L"微软雅黑", 15, false, DFontWeight::Normal, DAlignment::Near, DAlignment::Center);
	MainErr.SetTotalOpacity(0.0f);
	MainErrMsg.SetTotalOpacity(0.0f);

	Regi.Init({ ChatUIOfsX + 2, ChatUIOfsY + WindowHeight - 27 }, { 45, 25 },
		{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.6f }, 250 },
		{ { 0, 0, 0, 0.2f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.8f }, 250 },
		{ { 0, 0, 0, 0.35f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 0.8f }, 50 },
		{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.5f }, 200 },
		3.5f, 3.5f, 0.0f, L"注册", L"微软雅黑", 12, DFontWeight::Normal);

	Abou.Init({ ChatUIOfsX + WindowWidth - 47, ChatUIOfsY + WindowHeight - 27 }, { 45, 25 },
		{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.6f }, 250 },
		{ { 0, 0, 0, 0.2f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.8f }, 250 },
		{ { 0, 0, 0, 0.35f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 0.8f }, 50 },
		{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.5f }, 200 },
		3.5f, 3.5f, 0.0f, L"更多", L"微软雅黑", 12, DFontWeight::Normal);

	//更多部分控件
	Ret.Init({ ChatUIOfsX + WindowWidth + 2, ChatUIOfsY + WindowHeight - 27 }, { 45, 25 },
		{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.6f }, 250 },
		{ { 0, 0, 0, 0.2f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.8f }, 250 },
		{ { 0, 0, 0, 0.35f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 0.8f }, 50 },
		{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.5f }, 200 },
		3.5f, 3.5f, 0.0f, L"返回", L"微软雅黑", 12, DFontWeight::Normal);

	Vers.Init({ ChatUIOfsX + WindowWidth + 20, ChatUIOfsY + TitleHeight + 5 }, { WindowWidth - 40, 35 }, { 0, 0, 0, 1.0f }, true, L"版本：79B6494405EDC600", L"微软雅黑", 17, false, DFontWeight::Normal, DAlignment::Center, DAlignment::Center);

	Update.Init({ ChatUIOfsX + WindowWidth + 50, ChatUIOfsY + TitleHeight + 45 }, { WindowWidth - 100, 30 },
		{ { 0, 0, 0, 0.15f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 250 },
		{ { 0, 0, 0, 0.3f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 250 },
		{ { 0, 0, 0, 0.5f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 50 },
		{ { 0, 0, 0, 0.35f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 0.6f }, 150 },
		15.0f, 15.0f, 0.0f, L"检查并更新", L"微软雅黑", 15, DFontWeight::Normal);

	Proxy.Init({ ChatUIOfsX + WindowWidth + 30, ChatUIOfsY + TitleHeight + 95 }, { WindowWidth - 60, 35 },
		{ {0, 0, 0, 0.05f }, { 23, 181, 255, 0.1f }, { 0, 0, 0, 1.0f }, 250 },
		{ {0, 0, 0, 0.2f }, {23, 181, 255, 0.3f}, { 0, 0, 0, 1.0f }, 250 },
		{ {0, 0, 0, 0.15f }, {23, 181, 255, 0.3f}, { 0, 0, 0, 1.0f }, 150 },
		{ {0, 0, 0, 0.2f }, {0, 0, 0, 0.0f}, {0, 0, 0, 1.0f}, 200 },
		3.0f, 3.0f, 2.0f, L"微软雅黑", 16, false, false, false, DFontWeight::Bold, DAlignment::Near, DAlignment::Center, { 0, 0, 0, 1.0f }, 1.5f, { 0, 0, 0, 0.2f });

	Prox.Init({ ChatUIOfsX + WindowWidth + 35, ChatUIOfsY + TitleHeight + 96 }, { WindowWidth - 60, 34 }, { 0, 0, 0, 0.3f }, true, L"代理服务器", L"微软雅黑", 15, false, DFontWeight::Normal, DAlignment::Near, DAlignment::Center);

	UpdMsg.Init({ ChatUIOfsX + WindowWidth + 50, ChatUIOfsY + TitleHeight + 135 }, { WindowWidth - 100, 50 }, { 0, 0, 0, 0.7f }, true, L"", L"微软雅黑", 13, false, DFontWeight::Normal, DAlignment::Center, DAlignment::Center);
	/////////口令弹窗部分控件
	p[0].color = { 23, 181, 255, 1.0f };
	p[0].position = 0.0f;
	p[1].color = { 180, 31, 255, 1.0f };
	p[1].position = 1.0f;
	BackGro.Init({ 0, 0 }, { PopupWidth, PopupHeight }, { 0, 0, 0, 0.0f }, p, 2, { 0, 0 }, { PopupWidth, PopupHeight }, { 0 }, 0.0f, 0.0f, 0.0f, true);
	Comm.Init({ 20, 30 }, { 280, 100 },
		{ {0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 0 },
		{ {0, 0, 0, 0.0f }, {0, 0, 0, 0.0f}, { 255, 255, 255, 1.0f }, 0 },
		{ {0, 0, 0, 0.0f }, {0, 0, 0, 0.0f}, { 255, 255, 255, 1.0f }, 0 },
		{ {0, 0, 0, 0.0f }, {0, 0, 0, 0.0f}, {0, 0, 0, 1.0f}, 0 },
		0.0f, 0.0f, 0.0f, L"微软雅黑", 18, true, true, true, DFontWeight::Normal, DAlignment::Center, DAlignment::Center, { 0, 0, 0, 0.0f }, 0.0f, { 255, 255, 255, 0.3f });
	CommOK.Init({ 95, PopupHeight - 40 }, { 130, 30 },
		{ { 255, 255, 255, 0.15f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 255, 255, 255, 0.35f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 0, 0, 0, 0.3f }, { 0, 0, 0, 1.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 100 },
		15.0f, 15.0f, 0.0f, L"确定", L"微软雅黑", 17, DFontWeight::Normal);

	//Chat模式控件
	CClose.Init({ ChatWidth - 35, 0 }, { 35, 35 },
		{ { 255, 60, 40, 0.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 0.8f }, 250 },
		{ { 255, 70, 50, 1.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 150, 50, 30, 1.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		0.0f, 0.0f, 0.0f, L"×", L"微软雅黑", 30, DFontWeight::Light);

	CMini.Init({ ChatWidth - 70, 0 }, { 35, 35 },
		{ { 255, 255, 255, 0.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 0.8f }, 250 },
		{ { 255, 255, 255, 0.3f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 255, 255, 255, 0.5f }, { 0, 0, 0, 1.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		0.0f, 0.0f, 0.0f, L"—", L"微软雅黑", 13, DFontWeight::Bold);

	CRet.Init({ ChatWidth - 105, 0 }, { 35, 35 },
		{ { 255, 255, 255, 0.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 0.8f }, 250 },
		{ { 255, 255, 255, 0.3f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 255, 255, 255, 0.5f }, { 0, 0, 0, 1.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		0.0f, 0.0f, 0.0f, L"注销", L"微软雅黑", 12, DFontWeight::Normal);

	CTiB.Init({ 0, 0 }, { ChatWidth, TitleHeight }, { 0, 0, 0, 0.0f }, p, 2, { 0, TitleHeight / 2 }, { ChatWidth, TitleHeight / 2 }, { 0 }, 0.0f, 0.0f, 0.0f, true);

	CTi.Init({ 106, 0 }, { ChatWidth - 212, TitleHeight }, { 255, 255, 255, 1.0f }, true, L"ChatUI", L"微软雅黑", 19, false, DFontWeight::Normal, DAlignment::Center, DAlignment::Center);

	Content.Init({ 10, TitleHeight + 12 }, { ChatWidth - 20, 330 },
		{ {0, 0, 0, 0.1f }, { 23, 181, 255, 0.1f }, { 0, 0, 0, 1.0f }, 250 },
		{ {0, 0, 0, 0.1f }, { 23, 181, 255, 0.1f }, { 0, 0, 0, 1.0f }, 250 },
		{ {0, 0, 0, 0.1f }, { 23, 181, 255, 0.1f }, { 0, 0, 0, 1.0f }, 150 },
		{ {0, 0, 0, 0.1f }, {0, 0, 0, 0.0f}, {0, 0, 0, 1.0f}, 100 },
		3.0f, 3.0f, 2.0f, L"微软雅黑", 18, true, true, true, DFontWeight::Normal, DAlignment::Near, DAlignment::Near, { 0, 0, 0, 0.0f }, 1.5f, { 0, 0, 0, 0.2f });

	Send.Init({ 10, TitleHeight + 360 }, { ChatWidth - 20, 150 },
		{ {0, 0, 0, 0.1f }, { 23, 181, 255, 0.1f }, { 0, 0, 0, 1.0f }, 250 },
		{ {0, 0, 0, 0.20f }, {23, 181, 255, 0.3f}, { 0, 0, 0, 1.0f }, 250 },
		{ {0, 0, 0, 0.15f }, {23, 181, 255, 0.3f}, { 0, 0, 0, 1.0f }, 150 },
		{ {0, 0, 0, 0.35f }, {0, 0, 0, 0.0f}, {0, 0, 0, 1.0f}, 100 },
		3.0f, 3.0f, 2.0f, L"微软雅黑", 18, true, true, false, DFontWeight::Normal, DAlignment::Near, DAlignment::Near, { 0, 0, 0, 1.0f }, 1.5f, { 0, 0, 0, 0.2f });

	TSen.Init({ 15, TitleHeight + 360 }, { 100, 30 }, { 0, 0, 0, 0.3f }, true, L"发送内容", L"微软雅黑", 15, false, DFontWeight::Normal, DAlignment::Near, DAlignment::Center);

	SendBtn.Init({ 125, TitleHeight + 518 }, { 200, 35 }, { 0, 0, 0, 1.0f }, p, 2, { 50, 187 }, { 300, 187 }, { 0 }, 0.0f, 17.5f, 17.5f);

	TSendBtn.Init({ 125, TitleHeight + 518 }, { 200, 35 }, { 255, 255, 255, 1.0f }, true, L"发送", L"微软雅黑", 16, false, DFontWeight::Normal, DAlignment::Center, DAlignment::Center);

	MainErr.SetTotalOpacity(0.0f);
	MainErrMsg.SetTotalOpacity(0.0f);
	if (ErrTimer)
	{
		KillTimer(Main, 233);
		ErrTimer = 0;
	}
	
	Main.AddControl(&LoginBack, sw);
	Main.AddControl(&TiB, LoginBack);
	Main.AddControl(&Ti, TiB);
	Main.AddControl(&Close, TiB);
	Main.AddControl(&Mini, TiB);
	Main.AddControl(&Account, LoginBack);
	Main.AddControl(&Acc, Account, true);
	Main.AddControl(&MainBtn, LoginBack);
	Main.AddControl(&TBtn, MainBtn, true);
	Main.AddControl(&MainErr, LoginBack);
	Main.AddControl(&MainErrMsg, LoginBack);
	Main.AddControl(&Regi, LoginBack);
	Main.AddControl(&Abou, LoginBack);
	//更多部分
	Main.AddControl(&Ret, LoginBack);
	Main.AddControl(&Vers, LoginBack);
	Main.AddControl(&Update, LoginBack);
	Main.AddControl(&Proxy, LoginBack);
	Main.AddControl(&Prox, Proxy, true);
	Main.AddControl(&UpdMsg, LoginBack);
	return;
}

void __stdcall ChatUI_DConProc(HWND hWnd, UINT id, DControlType type, DControlMsg msg, WPARAM wParam, LPARAM lParam)
{
	if (hWnd == Main)//多窗口时的分辨处理
	{
		switch (msg)//分辨消息，并比较ID判断
		{
		case DControlMsg::TextBox_Enter:
			if (id == Account)
			{
				if (page == 1)//登录按钮被按下
					Login();
				else if (page == 0)//注册按钮被按下
					Register();
			}
			break;
		case DControlMsg::Control_Click://这里响应的按钮的按下操作
		{
			if (id == Close)//关闭按钮被按下
				MainErrorMsg(L"不能关哦", true);
			else if (id == Mini)//最小化按钮被按下
				MainErrorMsg(L"不能最小化哦", true);
			else if (id == MainBtn && page == 1)//登录按钮被按下
				Login();
			else if (id == MainBtn && page == 0)//注册按钮被按下
				Register();
			else if (id == Regi)
			{
				if (page == 1)//注册状态按钮被按下
					SetPage(0);
				else if (page == 0)//登录状态按钮被按下
					SetPage(1);
			}
			else if (id == Abou && (page == 0 || page == 1))//更多按钮被按下
				SetPage(2);
			else if (id == Ret && page == 2)//返回按钮被按下
			{
				if (Regi.GetText() == L"注册")
					SetPage(1);
				else if (Regi.GetText() == L"登录")
					SetPage(0);
			}
			else if (id == Update && page == 2)//返回按钮被按下
				UpdateClick();
			break;
		}
		case DControlMsg::Control_StateChanged:
		{
			DControlState after = (DControlState)lParam;
			if (id == Account)
			{
				if (after == DControlState::Edit)
				{
					Acc.SetText(L"");
					if (Account.GetLength())
						Account.SetSelectText_All();//首次点击自动全选的实现
				}
				else if (after == DControlState::Normal)
				{
					Account.ExitSelectMode();
					if (!Account.GetLength())
					{
						if (page == 1)
							Acc.SetText(L"口令");
						else if (page == 0)
							Acc.SetText(L"用户名");
					}
				}
			}
			else if (id == MainBtn)
			{
				if (after == DControlState::MouseMove)
					MainBtn.SetLinearOpacity(0.75f, 250);
				else if (after == DControlState::Normal)
					MainBtn.SetLinearOpacity(1.0f, 200);
				else if (after == DControlState::Click)
					MainBtn.SetLinearOpacity(0.6f, 50);
				else if (after == DControlState::Disable)
					MainBtn.SetLinearOpacity(0.8f, 150);
			}
			else if (id == Proxy)
			{
				if (after == DControlState::Edit)
				{
					Prox.SetText(L"");
					if (Proxy.GetLength())
						Proxy.SetSelectText_All();
				}
				else if (after == DControlState::Normal)
				{
					Proxy.ExitSelectMode();
					if (!Proxy.GetLength())
						Prox.SetText(L"代理服务器");
				}
			}
			break;
		}

		default:
			break;
		}
	}
	else if (hWnd == KeyPopup)
	{
		if (msg == DControlMsg::Control_Click && id == CommOK)
		{
			BackGro.SetTotalOpacity(0.0f, PopupAniTime);
			Comm.SetTotalOpacity(0.0f, PopupAniTime);
			CommOK.SetTotalOpacity(0.0f, PopupAniTime);
			KeyPopup.SetShadowAlpha(0.0f, PopupAniTime);
		}
	}
	else if (hWnd == Chat)
	{
		switch (msg)//分辨消息，并比较ID判断
		{
		case DControlMsg::Control_Click://这里响应的按钮的按下操作
		{
			if (id == CClose || id == CRet)//关闭注销按钮被按下
			{
				LoginMode();
				MainErrorMsg(L"Broken the connection", true);
			}
			else if (id == CMini)//最小化按钮被按下
				Chat.Show(SW_MINIMIZE);
			else if (id == SendBtn)
				SendClick();
			break;
		}
		case DControlMsg::Control_StateChanged:
		{
			DControlState after = (DControlState)lParam;
			if (id == Send)
			{
				if (after == DControlState::Edit)
					TSen.SetText(L"");
				else if (after == DControlState::Normal && !Send.GetLength())
					TSen.SetText(L"发送内容");
			}
			else if (id == SendBtn)
			{
				if (after == DControlState::MouseMove)
					SendBtn.SetLinearOpacity(0.75f, 250);
				else if (after == DControlState::Normal)
					SendBtn.SetLinearOpacity(1.0f, 200);
				else if (after == DControlState::Click)
					SendBtn.SetLinearOpacity(0.6f, 50);
				else if (after == DControlState::Disable)
					SendBtn.SetLinearOpacity(0.5f, 50);
			}
			break;
		}

		default:
			break;
		}
	}
	return;
}


void Login()
{
	Account.SetState(DControlState::Disable);
	MainBtn.SetState(DControlState::Disable);

	//登录按钮按下操作
	if (Account.GetLength() > 8 || !Account.GetLength())
	{
		if (!Account.GetLength())
			MainErrorMsg(L"Please input ID", true);//显示错误提示信息
		else
			MainErrorMsg(L"[ID] is not correct", true);//显示错误提示信息
		MainBtn.SetState(DControlState::Normal);
		Account.SetState(DControlState::Normal);
		return;
	}

	Sleep(500);//模拟与服务器交互时的耗时
	ChatMode(Account.GetText());//登录成功后切换到聊天页面

	MainBtn.SetState(DControlState::Normal);
	Account.SetState(DControlState::Normal);
	return;
}

void Register()
{
	Account.SetState(DControlState::Disable);
	MainBtn.SetState(DControlState::Disable);
	//注册按钮按下操作
	if (!Account.GetLength())
	{
		MainErrorMsg(L"Please input Username", true);//显示错误提示信息
		MainBtn.SetState(DControlState::Normal);
		Account.SetState(DControlState::Normal);
		return;
	}

	Sleep(500);//模拟与服务器交互时的耗时

	wchar_t res[256];
	swprintf_s(res, L"请求成功，请等待审核\n用户名：%s\n登录口令：%s", Account.GetText().c_str(), L"B233EF6C");
	CommandPopup(res);//用来显示注册成功后账户信息的弹窗

	MainBtn.SetState(DControlState::Normal);
	Account.SetState(DControlState::Normal);
	return;
}

void UpdateClick()
{
	Ret.SetState(DControlState::Disable);
	Update.SetState(DControlState::Disable);

	//更新按钮按下操作
	Update.SetText(L"连接中（假的）...");//设置更新按钮的文本
	Sleep(500);//模拟网络耗时
	Update.SetText(L"下载中（假的）...");//设置更新按钮的文本
	Sleep(500);//模拟网络耗时

	UpdateMsg(L"Updata Successfully\nPlease add suffix 'exe' to the file 'Client'.", true);

	Update.SetText(L"检查并更新");
	Update.SetState(DControlState::Normal);
	Ret.SetState(DControlState::Normal);
	return;
}

void SendClick()
{
	SendBtn.SetState(DControlState::Disable);
	//发送按钮按下操作

	if (Send.GetLength())
	{
		Sleep(100);//模拟网络耗时
		if (Content.GetLength())
			Content.AddChar(L'\n', false);
		Content.AddText(L"2020/4/26 18:18:08  " + CTi.GetText() + L'\n' + Send.GetText(), true);
	}
	//清空发送内容
	Send.SetText(L"");
	Send.ExitSelectMode();
	TSen.SetText(L"发送内容");
	SendBtn.SetState(DControlState::Normal);
	return;
}

void SetPage(UINT Page)
{
	if (Page == 0 || Page == 1)
	{
		if (page != 2)
			Account.SetText(L"");
		Account.ExitSelectMode();
		Account.SetPosition(ChatUIOfsX + 60, ChatUIOfsY + 88, MainAniTime, &b);
		Acc.SetPosition(ChatUIOfsX + 65, ChatUIOfsY + 88, MainAniTime, &b);
		MainErr.SetPosition(ChatUIOfsX + 55, ChatUIOfsY + 139, MainAniTime, &b);
		MainErrMsg.SetPosition(ChatUIOfsX + 73, ChatUIOfsY + 134, MainAniTime, &b);
		MainBtn.SetPosition(ChatUIOfsX + 50, ChatUIOfsY + 170, MainAniTime, &b);
		TBtn.SetPosition(ChatUIOfsX + 130, ChatUIOfsY + 170, MainAniTime, &b);
		Regi.SetPosition(ChatUIOfsX + 2, ChatUIOfsY + WindowHeight - 27, MainAniTime, &b);
		Abou.SetPosition(ChatUIOfsX + WindowWidth - 47, ChatUIOfsY + WindowHeight - 27, MainAniTime, &b);

		Ret.SetPosition(ChatUIOfsX + WindowWidth + 2, ChatUIOfsY + WindowHeight - 27, MainAniTime, &b);
		Vers.SetPosition(ChatUIOfsX + WindowWidth + 20, ChatUIOfsY + TitleHeight + 5, MainAniTime, &b);
		Update.SetPosition(ChatUIOfsX + WindowWidth + 50, ChatUIOfsY + TitleHeight + 45, MainAniTime, &b);
		Proxy.SetPosition(ChatUIOfsX + WindowWidth + 30, ChatUIOfsY + TitleHeight + 95, MainAniTime, &b);
		Prox.SetPosition(ChatUIOfsX + WindowWidth + 35, ChatUIOfsY + TitleHeight + 96, MainAniTime, &b);
		UpdMsg.SetPosition(ChatUIOfsX + WindowWidth + 50, ChatUIOfsY + TitleHeight + 135, MainAniTime, &b);
	}
	if (Page == 0)
	{
		MainBtn.SetStartPos({ ChatUIOfsX + 300, ChatUIOfsY + 187 }, 1200, &b);
		MainBtn.SetEndPos({ ChatUIOfsX + 50, ChatUIOfsY + 187 }, 1200, &b);
		TBtn.SetText(L"注册");
		Regi.SetText(L"登录");
		if (!Account.GetLength())
			Acc.SetText(L"用户名");
		page = 0;
	}
	else if (Page == 1)
	{
		MainBtn.SetStartPos({ ChatUIOfsX + 50, ChatUIOfsY + 187 }, 1200, &b);
		MainBtn.SetEndPos({ ChatUIOfsX + 300, ChatUIOfsY + 187 }, 1200, &b);
		TBtn.SetText(L"登录");
		Regi.SetText(L"注册");
		if (!Account.GetLength())
			Acc.SetText(L"口令");
		page = 1;
	}
	else if (Page == 2)
	{
		Account.SetPosition(ChatUIOfsX + 60 - WindowWidth, ChatUIOfsY + 88, MainAniTime, &b);
		Acc.SetPosition(ChatUIOfsX + 65 - WindowWidth, ChatUIOfsY + 88, MainAniTime, &b);
		MainErr.SetPosition(ChatUIOfsX + 55 - WindowWidth, ChatUIOfsY + 139, MainAniTime, &b);
		MainErrMsg.SetPosition(ChatUIOfsX + 73 - WindowWidth, ChatUIOfsY + 134, MainAniTime, &b);
		MainBtn.SetPosition(ChatUIOfsX + 50 - WindowWidth, ChatUIOfsY + 170, MainAniTime, &b);
		if (page == 1)
		{
			MainBtn.SetStartPos({ ChatUIOfsX + 50 - WindowWidth, ChatUIOfsY + 187 }, MainAniTime, &b);
			MainBtn.SetEndPos({ ChatUIOfsX + 300 - WindowWidth, ChatUIOfsY + 187 }, MainAniTime, &b);
		}
		else if (page == 0)
		{
			MainBtn.SetStartPos({ ChatUIOfsX + 300 - WindowWidth, ChatUIOfsY + 187 }, 1200, &b);
			MainBtn.SetEndPos({ ChatUIOfsX + 50 - WindowWidth, ChatUIOfsY + 187 }, 1200, &b);
		}
		TBtn.SetPosition(ChatUIOfsX + 130 - WindowWidth, ChatUIOfsY + 170, MainAniTime, &b);
		Regi.SetPosition(ChatUIOfsX + 2 - WindowWidth, ChatUIOfsY + WindowHeight - 27, MainAniTime, &b);
		Abou.SetPosition(ChatUIOfsX - 47, ChatUIOfsY + WindowHeight - 27, MainAniTime, &b);

		Ret.SetPosition(ChatUIOfsX + 2, ChatUIOfsY + WindowHeight - 27, MainAniTime, &b);
		Vers.SetPosition(ChatUIOfsX + 20, ChatUIOfsY + TitleHeight + 5, MainAniTime, &b);
		Update.SetPosition(ChatUIOfsX + 50, ChatUIOfsY + TitleHeight + 45, MainAniTime, &b);
		Proxy.SetPosition(ChatUIOfsX + 30, ChatUIOfsY + TitleHeight + 95, MainAniTime, &b);
		Prox.SetPosition(ChatUIOfsX + 35, ChatUIOfsY + TitleHeight + 96, MainAniTime, &b);
		UpdMsg.SetPosition(ChatUIOfsX + 50, ChatUIOfsY + TitleHeight + 135, MainAniTime, &b);
		page = 2;
	}
	return;
}

//注册成功后的口令弹窗
void CommandPopup(std::wstring Text)
{
	Comm.ExitSelectMode();
	Comm.SetText(Text);
	BackGro.SetTotalOpacity(0.0f);
	Comm.SetTotalOpacity(0.0f);
	CommOK.SetTotalOpacity(0.0f);
	KeyPopup.Release();

	KeyPopup.Parent = Main;
	KeyPopup.ExStyle = WS_EX_TOOLWINDOW;//不显示在任务栏中

	KeyPopup.SetTransparent(true);
	if (!KeyPopup.Create(hInst, L"ChatWndClass", L"ChatUI", WndProc, PopupWidth, PopupHeight))
		return;

	KeyPopup.Init(ChatUI_DConProc, 3.0f, 0.0f, true, 60, { 0, 0, 0, 0.0f });
	KeyPopup.AddControl(&BackGro);
	KeyPopup.AddControl(&Comm, BackGro);
	KeyPopup.AddControl(&CommOK, BackGro);
	KeyPopup.CreateRenderThread();
	KeyPopup.Show();

	BackGro.SetTotalOpacity(1.0f, PopupAniTime);
	Comm.SetTotalOpacity(1.0f, PopupAniTime);
	CommOK.SetTotalOpacity(1.0f, PopupAniTime);
	KeyPopup.SetShadowAlpha(0.7f, PopupAniTime);
	return;
}

void MainErrorMsg(const wchar_t* Text, bool hide)
{
	MainErrMsg.SetText(Text);
	MainErr.SetTotalOpacity(1.0f, 250);
	MainErrMsg.SetTotalOpacity(1.0f, 250);
	if (ErrTimer)
		KillTimer(Main, 233);
	if (hide)
		ErrTimer = SetTimer(Main, 233, 2000, nullptr);
	return;
}

void UpdateMsg(std::wstring Text, bool hide)
{
	UpdMsg.SetText(Text);
	UpdMsg.SetTotalOpacity(1.0f, 250);
	if (UpdMsgTimer)
		KillTimer(Main, 234);
	if (hide)
		UpdMsgTimer = SetTimer(Main, 234, 5000, nullptr);
	return;
}

void LoginMode()
{
	Chat.Release();
	KeyPopup.Release();

	MainErr.SetTotalOpacity(0.0f);
	MainErrMsg.SetTotalOpacity(0.0f);
	if (ErrTimer)
	{
		KillTimer(Main, 233);
		ErrTimer = 0;
	}
	return;
}

void ChatMode(std::wstring UserName)
{
	if (Chat.Create(hInst, L"ChatWndClass", L"ChatUI", WndProc, ChatWidth, ChatHeight) && Chat.Init(ChatUI_DConProc, 3.0f, 0.0f))
	{
		KeyPopup.Release();

		CTi.SetText(UserName);
		Content.SetOffsetY(0.0f);
		Content.MoveCaret(Content.GetLength());
		//清空内容
		Send.ExitSelectMode();
		Send.SetText(L"");
		TSen.SetText(L"发送内容");
		SendBtn.SetState(DControlState::Normal);
		SendBtn.SetLinearOpacity(1.0f);

		Chat.AddControl(&CTiB);
		Chat.AddControl(&CTi, CTiB);
		Chat.AddControl(&CClose, CTiB);
		Chat.AddControl(&CMini, CTiB);
		Chat.AddControl(&CRet, CTiB);
		Chat.AddControl(&Content);
		Chat.AddControl(&Send);
		Chat.AddControl(&TSen, Send, true);
		Chat.AddControl(&SendBtn);
		Chat.AddControl(&TSendBtn, SendBtn, true);

		Chat.SetShadowAlpha(0.5f, 350);
		Chat.Show();
		Chat.CreateRenderThread();
	}
	return;
}
