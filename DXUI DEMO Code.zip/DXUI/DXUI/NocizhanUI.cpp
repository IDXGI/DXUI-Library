﻿#include "Main.h"

DSolidColorBox NociBack;
DLinearColorBox No_TiB;
DLabel No_Ti;
DButton No_Close;
DButton MinSize;
DSolidColorBox PlanViewB;
DScrollView PlanView;
DButton PackMgr;
DImageBox PackImg;
DButton NewPlan;
DButton DelPlan;
DLabel PlanNum;

//其它附加窗口
PackMgrUI MgrWndUI;//包管理窗口类
PackEditUI EditWndUI;//包编辑窗口类

//列表相关
typedef struct _tagPlanItem
{
	DSolidColorBox* Back;
	DImageBox* Icon;
	DLabel* Name;
	DButton* Del;
}PlanItem;

std::map<UINT, PlanItem> plans;
___DThreadLock planLock;
float PlanFullHeight = 0.0f;
#define PlanSpacing 7.0f

//主窗口的参数定义
#define WindowWidth  740
#define WindowHeight 500
void AddPlan();
void DeletePlan();

bool No_Init()
{
	NociBack.Init({ NoUIOfsX, NoUIOfsY }, { WindowWidth, WindowHeight }, { 255, 255, 255, 0.9f });
	DColorBox_Point p[2];
	p[0].color = { 0, 236, 116, 1.0f };
	p[0].position = 0.0f;
	p[1].color = { 0, 174, 247, 1.0f };
	p[1].position = 1.0f;
	No_TiB.Init({ NoUIOfsX, NoUIOfsY}, { WindowWidth, 40 }, { 0, 0, 0, 0.0f }, p, 2, { 0, 40 }, { WindowWidth, 0 }, { 0 }, 0.0f, 0.0f, 0.0f, true);
	No_Ti.Init({ NoUIOfsX + 250, NoUIOfsY}, { WindowWidth - 500, 40 },
		{ { 255, 255, 255, 1.0f }, false, false, 0 },
		{ { 255, 255, 255, 1.0f }, false, false, 0 },
		{ { 255, 255, 255, 1.0f }, false, false, 0 },
		true, L"没词斩 - DXUI Demo", L"微软雅黑", 20, false, DFontWeight::Medium, DAlignment::Center, DAlignment::Center);

	No_Close.Init({ NoUIOfsX + WindowWidth - 35, NoUIOfsY}, { 35, 35 },
		{ { 255, 60, 40, 0.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 255, 70, 50, 0.8f }, { 200, 200, 200, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 150, 50, 30, 1.0f }, { 150, 150, 200, 0.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		0.0f, 0.0f, 0.0f, L"✕", L"微软雅黑", 18, DFontWeight::Normal);

	MinSize.Init({ NoUIOfsX + WindowWidth - 70, NoUIOfsY}, { 35, 35 },
		{ { 255, 255, 255, 0.0f }, { 26, 217, 110, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 255, 255, 255, 0.4f }, { 35, 231, 131, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 255, 255, 255, 0.6f }, { 31, 207, 108, 1.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		0.0f, 0.0f, 0.0f, L"—", L"微软雅黑", 13, DFontWeight::Bold);

	PlanViewB.Init({ NoUIOfsX + 15, NoUIOfsY + 50 }, { WindowWidth - 30, 350 }, { 255, 255, 255, 1.0f }, { 217, 217, 217, 1.0f }, 1.5f, 7.0f, 7.0f);
	PlanView.Init({ NoUIOfsX + 15, NoUIOfsY + 50 }, { WindowWidth - 30, 350 }, 0.0f, 70.0f, 200, true, true);

	PackMgr.Init({ NoUIOfsX + 15, NoUIOfsY + 433 }, { 115, 55 },
		{ { 230, 230, 230, 1.0f }, { 0, 0, 0, 0.0f }, { 70, 70, 70, 1.0f }, 200 },
		{ { 190, 190, 190, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 150 },
		{ { 130, 130, 130, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 50 },
		{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, 300 },
		7.0f, 7.0f, 0.0f, L"       包管理", L"微软雅黑", 20, DFontWeight::Medium);

	PackImg.Init({ NoUIOfsX + 17, NoUIOfsY + 438 }, { 45, 45 }, false, DScaleMode::Fill, 0.95f);
	PackImg.LoadFromResource(PIC_PACK, L"png", nullptr);
	NewPlan.Init({ NoUIOfsX + 440, NoUIOfsY + 439 }, { 135, 45 },
		{ { 230, 230, 230, 1.0f }, { 0, 0, 0, 0.0f }, { 70, 70, 70, 1.0f }, 200 },
		{ { 190, 190, 190, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 150 },
		{ { 130, 130, 130, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 50 },
		{ { 230, 230, 230, 1.0f }, { 0, 0, 0, 0.0f }, { 70, 70, 70, 1.0f }, 120 },
		7.0f, 7.0f, 0.0f, L"新建计划", L"微软雅黑", 20, DFontWeight::Medium);

	DelPlan.Init({ NoUIOfsX + 585, NoUIOfsY + 439 }, { 135, 45 },
		{ { 230, 230, 230, 1.0f }, { 0, 0, 0, 0.0f }, { 70, 70, 70, 1.0f }, 200 },
		{ { 190, 190, 190, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 150 },
		{ { 130, 130, 130, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 50 },
		{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, 300 },
		7.0f, 7.0f, 0.0f, L"删除计划", L"微软雅黑", 20, DFontWeight::Medium);

	PlanNum.Init({ NoUIOfsX + 20, NoUIOfsY + 405 }, { 200, 25 }, { 50, 50, 50, 0.9f }, false, L"计划数：0 个", L"微软雅黑", 15, false, DFontWeight::Medium);

	Main.AddControl(&NociBack, sw);
	Main.AddControl(&No_TiB, NociBack);
	Main.AddControl(&No_Ti, No_TiB, true);
	Main.AddControl(&No_Close, No_TiB);
	Main.AddControl(&MinSize, No_TiB);
	Main.AddControl(&PlanViewB, NociBack);
	Main.AddControl(&PlanView, PlanViewB);
	Main.AddControl(&PackMgr, NociBack);
	Main.AddControl(&PlanNum, NociBack);
	Main.AddControl(&PackImg, PackMgr, true);
	Main.AddControl(&NewPlan, NociBack);
	Main.AddControl(&DelPlan, NociBack);
	return true;
}

//接收DXUI控件消息的回调函数
void __stdcall No_ConProc(HWND hWnd, UINT id, DControlType type, DControlMsg msg, WPARAM wParam, LPARAM lParam)
{
	if (hWnd == Main)
	{
		switch (msg)
		{
		case DControlMsg::Control_Click:
		{
			if (id == CloseB)//主窗口关闭按钮被按下
			{
				planLock.Lock();
				std::map<UINT, PlanItem>::iterator it = plans.begin();
				while (it != plans.end())
				{
					it->second.Back->Release();
					it->second.Icon->Release();
					it->second.Name->Release();
					it->second.Del->Release();
					++it;
				}
				plans.clear();
				//设置标签显示数量
				wchar_t sOut[256];
				swprintf_s(sOut, L"计划数：%d 个", plans.size());
				PlanNum.SetText(sOut);
				planLock.Unlock();
			}
			else if (id == PackMgr)
			{
				MgrWndUI.Show(WndProc, Main);
			}
			else if (id == NewPlan)
			{
				AddPlan();
			}
			else if (id == DelPlan)
			{
				DeletePlan();
			}
			else if (type == DControlType::Button)//列表的某一计划删除键被点击
			{
				planLock.Lock();
				std::map<UINT, PlanItem>::iterator planit = plans.find(id - 3);
				if (planit != plans.end())
				{
					float dstY = planit->second.Back->GetPositionY(true);
					planit->second.Back->SetSize(0.0f, 0.0f, 350, &b, 886);
					planit->second.Back->SetTotalOpacity(0.0f, 150);
					planit->second.Icon->SetTotalOpacity(0.0f, 170);
					planit->second.Name->SetTotalOpacity(0.0f, 150);
					
					++planit;
					for (UINT i = 0; planit != plans.end(); ++i)
					{
						planit->second.Back->SetPosition(NoUIOfsX + 22.0f, dstY + 67 * i, 350, &b);
						planit->second.Icon->SetPosition(NoUIOfsX + 25.0f, dstY + 67 * i + 8, 350, &b);
						planit->second.Name->SetPosition(NoUIOfsX + 75.0f, dstY + 67 * i + 15, 350, &b);
						planit->second.Del->SetPosition(NoUIOfsX + 650.0f, dstY + 67 * i + 15, 350, &b);
						++planit;
					}
					PlanView.SetFullHeight(67.0f * ((float)plans.size() - 1.0f) + PlanSpacing);
				}
				planLock.Unlock();
			}
			break;
		}
		case DControlMsg::Control_StateChanged:
		{
			DControlState after = (DControlState)lParam;
			planLock.Lock();
			std::map<UINT, PlanItem>::iterator planit = plans.find(id);
			if (planit != plans.end() && DelPlan.GetText() != L"完  成")
			{
				if (after == DControlState::MouseMove)
					planit->second.Back->SetFillColor({ 210, 210, 210, 1.0f }, 200);
				else if (after == DControlState::Normal)
					planit->second.Back->SetFillColor({ 237, 237, 237, 1.0f }, 200);
				else if (after == DControlState::Click)
					planit->second.Back->SetFillColor({ 180, 180, 180, 1.0f }, 100);
			}
			planLock.Unlock();
			break;
		}
		case DControlMsg::Control_EndOfAnimation:
		{
			if (wParam == 886)//有计划被删除
			{
				planLock.Lock();
				std::map<UINT, PlanItem>::iterator planit = plans.find(id);
				if (planit != plans.end())
				{
					Main.DeleteControl((UINT)id + 3);
					Main.DeleteControl((UINT)id + 2);
					Main.DeleteControl((UINT)id + 1);
					Main.DeleteControl((UINT)id);
					delete planit->second.Back;
					delete planit->second.Icon;
					delete planit->second.Name;
					delete planit->second.Del;
					plans.erase(id);
					//设置标签显示数量
					wchar_t sOut[256];
					swprintf_s(sOut, L"计划数：%d 个", plans.size());
					PlanNum.SetText(sOut);
				}
				planLock.Unlock();
			}
			break;
		}
		}
	}
	return;
}

void AddPlan()
{
	PlanItem plit;
	plit.Back = new DSolidColorBox;
	plit.Icon = new DImageBox;
	plit.Name = new DLabel;
	plit.Del = new DButton;

	if (!plit.Back || !plit.Icon || !plit.Name || !plit.Del)
		return;

	planLock.Lock();

	PlanFullHeight = 67.0f * (float)plans.size() + PlanSpacing;

	plit.Back->Init({ NoUIOfsX + 22, NoUIOfsY + 50 + (long)(PlanFullHeight) }, { 0, 0 }, { 237, 237, 237, 1.0f }, { 0, 0, 0, 0.0f }, 0.0f, 5.0f, 5.0f);
	plit.Icon->Init({ NoUIOfsX + 25, NoUIOfsY + 50 + (long)(PlanFullHeight) + 8 }, { 44, 44 }, false, DScaleMode::Fill);
	plit.Icon->LoadFromResource(PIC_PLAN, L"png", nullptr);
	plit.Name->Init({ NoUIOfsX + 75, NoUIOfsY + 50 + (long)(PlanFullHeight) + 15 }, { 200, 30 },
		{ { 50, 50, 50, 1.0f }, false, false, 0 },
		{ { 50, 50, 50, 1.0f }, false, false, 0 },
		{ { 50, 50, 50, 1.0f }, false, false, 0 },
		true, L"计划一", L"微软雅黑", 20, false, DFontWeight::Medium, DAlignment::Near, DAlignment::Center);

	plit.Del->Init({ NoUIOfsX + 650, NoUIOfsY + 50 + (long)(PlanFullHeight) + 15 }, { 55, 30 },
		{ { 255, 100, 70, 0.8f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 255, 70, 40, 1.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 200, 40, 20, 1.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 255, 83, 57, 0.8f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
		15.0f, 15.0f, 0.0f, L"删除", L"微软雅黑", 14, DFontWeight::Medium);

	//添加插入动画
	plit.Back->SetTotalOpacity(0.0f);
	plit.Icon->SetTotalOpacity(0.0f);
	plit.Name->SetTotalOpacity(0.0f);
	plit.Del->SetTotalOpacity(0.0f);

	plit.Back->SetTotalOpacity(1.0f, 150);
	plit.Icon->SetTotalOpacity(1.0f, 170);
	plit.Name->SetTotalOpacity(1.0f, 150);
	plit.Back->SetSize(WindowWidth - 44, 60.0f, 350, &b);

	Main.AddControl(plit.Back, PlanView);
	Main.AddControl(plit.Icon, plit.Back->GetID(), true);
	Main.AddControl(plit.Name, plit.Back->GetID(), true);
	Main.AddControl(plit.Del, plit.Back->GetID(), false);

	plans.insert(std::pair<UINT, PlanItem>(plit.Back->GetID(), plit));
	//设置标签显示数量
	wchar_t sOut[256];
	swprintf_s(sOut, L"计划数：%d 个", plans.size());
	PlanNum.SetText(sOut);
	planLock.Unlock();
	PlanFullHeight += 60.0f;
	PlanView.SetFullHeight(PlanFullHeight + PlanSpacing);
	PlanView.SetScrollOffset(PlanView.GetFullHeight() - PlanView.GetHeight(), 350, &b);
	return;
}
void DeletePlan()
{
	planLock.Lock();
	if (DelPlan.GetText() == L"删除计划")
	{
		NewPlan.SetState(DControlState::Disable);
		NewPlan.SetTotalOpacity(0.0f, 150);
		DelPlan.SetText(L"完  成");

		std::map<UINT, PlanItem>::iterator it = plans.begin();
		while (it != plans.end())
		{
			it->second.Del->SetTotalOpacity(1.0f, 150);
			++it;
		}
	}
	else {
		NewPlan.SetState(DControlState::Normal);
		NewPlan.SetTotalOpacity(1.0f, 150);
		DelPlan.SetText(L"删除计划");

		std::map<UINT, PlanItem>::iterator it = plans.begin();
		while (it != plans.end())
		{
			it->second.Del->SetTotalOpacity(0.0f, 150);
			++it;
		}
	}
	planLock.Unlock();
	return;
}
