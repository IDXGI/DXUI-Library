﻿/******************************************************************

	DXUI界面库 - 示例程序 v210221
	作者: YZ
	QQ: 2441987560
	WeChat: yangzhen2441987560
	Email: 2441987560@qq.com
	Github: https://github.com/IDXGI/DXUI-Libaray

	此库来之不易，使用请标明作者。商业用途请先联系我。
	共同维护良好的开源环境！

*******************************************************************/

#include "Main.h"
//动画的贝塞尔曲线参数
DBezier b = { 0.19f, 1.0f, 0.22f, 1.0f };

DWindow Main;
DWindow About;
//主窗口部分
DImageBox ib;
DRadialColorBox TitleB;
DLabel DXUI;
DLabel Close;
DRadialColorBox CloseB;
DLabel MinSize;
DRadialColorBox MinB;
//Dock栏
DSolidColorBox Dock;
DLabel SetBackImg;
DRadialColorBox SetBackImgB;
DLabel BAbout;
DRadialColorBox BAboutB;
DLabel CPURate;
DLabel MemInfo;
DTextBox github;
//主窗口_滚动视图部分
DScrollView sw;
//滚动视图_调试部分
DSolidColorBox Dbg_Back;
DButton ShowUpdateRect;
DButton SetLayered;
DButton SetBlur;
//About窗口
DSolidColorBox AboutBack;
DButton About_OK;
DLabel my;

HINSTANCE hInst;//当前实例
//主窗口的参数定义
#define Title          L"DXUI Demo"//标题栏文本
#define WindowClass    L"DXUI Class"//主窗口类名
#define WindowWidth    1100
#define WindowHeight   600
#define DBG_SIGMA      5.0f//调试栏背景的模糊程度
#define DOCK_SIGMA     15.0f//Dock栏背景模糊程度

//关于窗口的长宽定义
#define AboutWidth  400
#define AboutHeight 500

//动画时长
#define TextShowAniTime 600
#define TitleBAniTime   1500
//获取性能信息的相关函数
#define UpdateDelay 500//更新信息间隔

void __stdcall DConProc(HWND hWnd, UINT id, DControlType type, DControlMsg msg, WPARAM wParam, LPARAM lParam);
void __cdecl UpdateInformationThread(void* param);
unsigned long long FileTimeSub(FILETIME ftEndTime, FILETIME ftStartTime);
UINT GetCPUUsageRate();
void SetMemoryInfo();
POINT RandPoint(long Xmin, long Xmax, long Ymin, long Ymax);
bool UpdateThreadAlive = false;
bool UpdateInfo = true;
BOOL InitInstance(HINSTANCE, int);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPWSTR lpCmdLine, _In_ int nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	hInst = hInstance;
	//执行应用程序初始化:
	if (!InitInstance(hInstance, nCmdShow))
	{
		return false;
	}
	MSG msg;
	//主消息循环:
	while (GetMessageW(&msg, nullptr, 0, 0))
	{
		if (!TranslateAcceleratorW(msg.hwnd, nullptr, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessageW(&msg);
		}
	}

	//如果刷新占用的线程没退出，则等待退出
	UpdateInfo = false;
	while (UpdateThreadAlive)
	{
		Sleep(50);
	}

	return (int)msg.wParam;
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	hInst = hInstance;
	//****由于DXUI库全面支持高DPI场景，所以在使用前 应在项目设置里设置高DPI支持，来防止系统缩放 导致模糊****
	Main.hIcon = LoadIconW(hInst, MAKEINTRESOURCE(IDI_DXUI));
	Main.hIconSmall = LoadIconW(hInst, MAKEINTRESOURCE(IDI_SMALL));
	if (!Main.Create(hInst, WindowClass, Title, WndProc, WindowWidth, WindowHeight))
		return false;

	//使用步骤：初始化各个控件及窗口 —— 向窗口添加控件 —— 创建渲染线程 —— 显示窗口
	DColorBox_Point p[3];
	ib.Init({ 0, 0 }, { WindowWidth, WindowHeight }, true, DScaleMode::Fill);
	ib.LoadFromResource(PIC_BACK, L"pic", nullptr);

	Close.Init({ WindowWidth - 35, 0 }, { 35, 35 },
		{ { 255, 255, 255, 0.8f }, false, false, 250 },
		{ { 255, 255, 255, 1.0f }, false, false, 250 },
		{ { 255, 255, 255, 1.0f }, false, false, 50 },
		false, L"✕", L"微软雅黑", 18, false, DFontWeight::Normal, DAlignment::Center, DAlignment::Center);

	MinSize.Init({ WindowWidth - 70, 0 }, { 35, 35 },
		{ { 255, 255, 255, 0.8f }, false, false, 250 },
		{ { 255, 255, 255, 1.0f }, false, false, 250 },
		{ { 255, 255, 255, 1.0f }, false, false, 50 },
		false, L"—", L"微软雅黑", 13, false, DFontWeight::Bold, DAlignment::Center, DAlignment::Center);

	DXUI.Init({ WindowWidth / 2 - 75, 0 }, { 150, 35 },
		{ { 255, 255, 255, 0.9f }, false, false, 0 },
		{ { 255, 255, 255, 0.9f }, false, false, 0 },
		{ { 255, 255, 255, 0.9f }, false, false, 0 },
		false, L"DXUI 界面库", L"微软雅黑", 20, false, DFontWeight::Medium, DAlignment::Center, DAlignment::Center);

	p[0].color = { 21, 183, 255, 1.0f };
	p[0].position = 0.0f;
	p[1].color = { 180, 31, 255, 1.0f };
	p[1].position = 1.0f;
	TitleB.Init({ 0, 0 }, { WindowWidth, 35 }, { 0, 0, 0, 0.0f }, p, 2, { WindowWidth / 2, 17 }, WindowWidth / 2.0f, WindowHeight / 2.0f, { 0 }, 0.0f, 0.0f, 0.0f, true);
	TitleB.SetTotalOpacity(0.7f);
	TitleB.SetBackgroundGaussianBlur(12.0f);
	p[0].color = { 255, 255, 255, 0.25f };
	p[0].position = 0.0f;
	p[1].color = { 255, 255, 255, 0.25f };
	p[1].position = 0.7f;
	p[2].color = { 255, 255, 255, 0.0f };
	p[2].position = 0.71f;
	CloseB.Init({ WindowWidth - 35, 0 }, { 35, 35 }, { 255, 255, 255, 0.0f }, p, 3, { 0, 0 }, 0.0f, 0.0f, { 0, 0, 0, 0.0f }, 0.0f, 0.0f, 0.0f);
	MinB.Init({ WindowWidth - 70, 0 }, { 35, 35 }, { 255, 255, 255, 0.0f }, p, 3, { 0, 0 }, 0.0f, 0.0f, { 0, 0, 0, 0.0f }, 0.0f, 0.0f, 0.0f);
	//Dock栏
	Dock.Init({ 10, WindowHeight - 40 }, { WindowWidth - 20, 36 }, { 35, 35, 35, 0.0f }, { 0 }, 0.0f, 17.5f, 17.5f);
	Dock.SetBackgroundGaussianBlur(DOCK_SIGMA);
	SetBackImg.Init({ WindowWidth - 243, WindowHeight - 40 }, { 110, 36 },
		{ { 255, 255, 255, 0.9f }, false, false, 250 },
		{ { 255, 255, 255, 1.0f }, false, false, 250 },
		{ { 255, 255, 255, 1.0f }, false, false, 50 },
		false, L"设置背景图", L"微软雅黑", 15, false, DFontWeight::Normal, DAlignment::Center, DAlignment::Center);

	BAbout.Init({ WindowWidth - 120, WindowHeight - 40 }, { 110, 36 },
		{ { 255, 255, 255, 0.9f }, false, false, 250 },
		{ { 255, 255, 255, 1.0f }, false, false, 250 },
		{ { 255, 255, 255, 1.0f }, false, false, 50 },
		false, L"About", L"微软雅黑", 17, false, DFontWeight::Normal, DAlignment::Center, DAlignment::Center);

	SetBackImgB.Init({ WindowWidth - 243, WindowHeight - 40 }, { 110, 36 }, { 255, 255, 255, 0.0f }, p, 3, { 0, 0 }, 0.0f, 0.0f, { 0, 0, 0, 0.0f }, 0.0f, 18.0f, 17.5f);
	BAboutB.Init({ WindowWidth - 120, WindowHeight - 40 }, { 110, 36 }, { 255, 255, 255, 0.0f }, p, 3, { 0, 0 }, 0.0f, 0.0f, { 0, 0, 0, 0.0f }, 0.0f, 17.5f, 18.0f);

	CPURate.Init({ 94, WindowHeight - 35 }, { 0, 25 },
		{ { 255, 255, 255, 0.8f }, false, false, 250 },
		{ { 255, 255, 255, 1.0f }, false, false, 250 },
		{ { 255, 255, 255, 1.0f }, false, false, 100 },
		false, L"系统 CPU 占用：0 %", L"微软雅黑", 16, false, DFontWeight::Normal, DAlignment::Near, DAlignment::Center);

	MemInfo.Init({ 363, WindowHeight - 35 }, { 0, 25 },
		{ { 255, 255, 255, 0.8f }, false, false, 250 },
		{ { 255, 255, 255, 1.0f }, false, false, 250 },
		{ { 255, 255, 255, 1.0f }, false, false, 100 },
		false, L"内存：0.0 MB | 峰值内存：0.0 MB (不准)", L"微软雅黑", 16, false, DFontWeight::Normal, DAlignment::Near, DAlignment::Center);

	github.Init({ WindowWidth - 412, WindowHeight - 35 }, { 0, 25 },
		{ {0, 0, 0, 0.0f}, {0, 0, 0, 0.0f}, {255, 255, 255, 0.8f}, 250 },
		{ {0, 0, 0, 0.0f}, {0, 0, 0, 0.0f}, {255, 255, 255, 1.0f}, 250 },
		{ {0, 0, 0, 0.0f}, {0, 0, 0, 0.0f}, {255, 255, 255, 1.0f}, 100 },
		{ {0, 0, 0, 0.0f}, {0, 0, 0, 0.0f}, {255, 255, 255, 1.0f}, 300 },
		0.0f, 0.0f, 0.0f, L"微软雅黑", 16, false, false, true, DFontWeight::Normal, DAlignment::Near, DAlignment::Center,
		{ 255, 255, 255, 1.0f }, 0.0f, { 255, 255, 255, 0.3f }, false, false);

	github.SetText(L"https://github.com/IDXGI/DXUI-Library");//文本框被设为只读，但SetText可以设置，用户无法修改
	github.MoveCaret(0);
	//滚动视图
	sw.Init({ 0, 36 }, { WindowWidth, WindowHeight - 80 }, 1200.0f, 55.0f, 200, true, true);
	Dbg_Back.Init({ 320, 50 }, { WindowWidth - 640, 60 }, { 255, 255, 255, 0.35f }, { 0 }, 0.0f, 7.0f, 7.0f);
	Dbg_Back.SetBackgroundGaussianBlur(DBG_SIGMA);

	ShowUpdateRect.CursorStyle = LoadCursorW(nullptr, IDC_HAND);
	ShowUpdateRect.Init({ 334, 60 }, { 138, 40 },
		{ { 50, 50, 50, 0.0f }, { 50, 50, 50, 0.95f }, { 50, 50, 50, 0.95f }, 250 },
		{ { 50, 50, 50, 1.0f }, { 50, 50, 50, 1.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 100, 100, 100, 1.0f }, { 100, 100, 100, 1.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		7.0f, 7.0f, 1.5f, L"显示更新区域", L"微软雅黑", 17);
	SetLayered.CursorStyle = LoadCursorW(nullptr, IDC_HAND);
	SetLayered.Init({ 481, 60 }, { 138, 40 },
		{ { 50, 50, 50, 0.0f }, { 50, 50, 50, 0.95f }, { 50, 50, 50, 0.95f }, 250 },
		{ { 50, 50, 50, 1.0f }, { 50, 50, 50, 1.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 100, 100, 100, 1.0f }, { 100, 100, 100, 1.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		7.0f, 7.0f, 1.5f, L"切换透明窗口", L"微软雅黑", 17);
	SetBlur.CursorStyle = LoadCursorW(nullptr, IDC_HAND);
	SetBlur.Init({ 628, 60 }, { 138, 40 },
		{ { 50, 50, 50, 0.0f }, { 50, 50, 50, 0.95f }, { 50, 50, 50, 0.95f }, 250 },
		{ { 50, 50, 50, 1.0f }, { 50, 50, 50, 1.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 100, 100, 100, 1.0f }, { 100, 100, 100, 1.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		7.0f, 7.0f, 1.5f, L"设置背景模糊(Win10)", L"微软雅黑", 13);
	//About窗口
	AboutBack.Init({ 0, 0 }, { AboutWidth, AboutHeight }, { 235, 235, 235, 1.0f }, { 0 }, 0.0f, 7.0f, 7.0f, true);
	About_OK.CursorStyle = LoadCursorW(nullptr, IDC_HAND);
	About_OK.Init({ AboutWidth / 2 - 50, AboutHeight - 60 }, { 100, 40 },
		{ { 50, 50, 50, 0.0f }, { 50, 50, 50, 1.0f }, { 50, 50, 50, 1.0f }, 250 },
		{ { 50, 50, 50, 1.0f }, { 50, 50, 50, 1.0f }, { 255, 255, 255, 1.0f }, 250 },
		{ { 100, 100, 100, 1.0f }, { 100, 100, 100, 1.0f }, { 255, 255, 255, 1.0f }, 50 },
		{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
		20, 20, 2.0f, L"确定", L"微软雅黑", 22, DFontWeight::Light);

	std::wstring aboutStr = L"杨X，山东济南，目前高二，会点C/C++，大概学了5年了，平时喜欢编程。\n\n此库来之不易，使用请标明作者。商业用途请先联系我。\nQQ: 2441987560\nWeChat: yangzhen2441987560\nEmail: 2441987560@qq.com\n\n编译时间: ";
	aboutStr += c2w(__TIMESTAMP__);
	aboutStr += L"\nDXUI库版本: ";
	wchar_t sOut[256];
	swprintf_s(sOut, L"%d\n发行版本: ", DXUI_VERSION);
	aboutStr += sOut;
#ifdef _DEBUG
	aboutStr += L"Debug";
#else
	aboutStr += L"Release";
#endif

	my.Init({ 20, 0 }, { AboutWidth - 40, AboutHeight - 120 },
		{ { 0, 0, 0, 1.0f }, false, false, 250 },
		{ { 0, 0, 0, 1.0f }, false, false, 250 },
		{ { 0, 0, 0, 1.0f }, false, false, 100 },
		true, aboutStr.c_str(),
		L"微软雅黑", 20, true, DFontWeight::Bold, DAlignment::Center, DAlignment::Center);

	//主窗口初始化
	Main.Init(DConProc, 2.0f, 0.0f, true, 60, { 0, 0, 0, 0.0f });
	//添加控件，控件遮盖关系以添加的顺序为依据
	//如果想让某控件的背景为另一个控件，则必须添加背景控件为该控件的Parent，那该控件叫做背景控件的Child
	//Child控件不能超出Parent控件，超出后会以Parent控件的边缘裁剪
	Main.AddControl(&ib);
	Main.AddControl(&TitleB, ib);
	Main.AddControl(&DXUI, TitleB, true);
	Main.AddControl(&CloseB, TitleB);
	Main.AddControl(&Close, CloseB, true);
	Main.AddControl(&MinB, TitleB);
	Main.AddControl(&MinSize, MinB, true);
	//Dock
	Main.AddControl(&Dock, ib);
	Main.AddControl(&SetBackImgB, Dock);
	Main.AddControl(&SetBackImg, SetBackImgB, true);
	Main.AddControl(&BAboutB, Dock);
	Main.AddControl(&BAbout, BAboutB, true);
	Main.AddControl(&CPURate, Dock);
	Main.AddControl(&MemInfo, Dock);
	Main.AddControl(&github, Dock);
	//滚动视图
	Main.AddControl(&sw, ib);
	Main.AddControl(&Dbg_Back, sw);
	Main.AddControl(&ShowUpdateRect, Dbg_Back);
	Main.AddControl(&SetLayered, Dbg_Back);
	Main.AddControl(&SetBlur, Dbg_Back);
	//ChatUI加载
	InitChatUI();
	//没词斩加载
	No_Init();
	//鼠标连点器
	ClickInit();
	//绘制是在一个独立的线程内进行的（保证了流畅性），这里要创建一个渲染线程，所有控件就开始绘制了
	Main.CreateRenderThread();
	_beginthread(UpdateInformationThread, 0, nullptr);//这是更新左下角性能信息的线程，在里面循环获取信息并设置文本框的内容（DXUI库线程安全，用户可在任意线程调用）
	Main.Show();
	Main.SetShadowAlpha(0.9f, 250);
	//设置底部文字显示动画
	Dock.SetFillColor({ 35, 35, 35, 0.35f }, 300);
	CPURate.SetPosition(18, WindowHeight - 35, TextShowAniTime, &b);
	CPURate.SetSize(173.0f, 25.0f, TextShowAniTime, &b);
	MemInfo.SetPosition(193, WindowHeight - 35, TextShowAniTime, &b);
	MemInfo.SetSize(338.0f, 25.0f, TextShowAniTime, &b);
	github.SetPosition(WindowWidth - 572, WindowHeight - 35, TextShowAniTime, &b);
	github.SetSize(320.0f, 25.0f, TextShowAniTime, &b);
	return true;
}

void __stdcall DConProc(HWND hWnd, UINT id, DControlType type, DControlMsg msg, WPARAM wParam, LPARAM lParam)
{
	ChatUI_DConProc(hWnd, id, type, msg, wParam, lParam);
	No_ConProc(hWnd, id, type, msg, wParam, lParam);
	ClickDConProc(hWnd, id, type, msg, wParam, lParam);

	if (msg == DControlMsg::Control_EndOfAnimation)
	{
		if (wParam == 8)
			About.Release();
	}
	else if (hWnd == Main)//多窗口时的分辨处理
	{
		switch (msg)//分辨消息，并比较ID判断
		{
		case DControlMsg::Control_Click://这里响应的按钮的按下操作
		{
			if (id == CloseB)
			{
				Main.Release();
			}
			else if (id == MinB)
			{
				Main.Show(SW_SHOWMINIMIZED);
			}
			else if (id == SetBackImgB)//设置背景图按钮被按下，这里弹出文件浏览框并设置图片
			{
				OPENFILENAMEW ofn = { 0 };
				wchar_t szFile[256] = { 0 };
				wchar_t szFileTitle[256] = { 0 };
				ofn.lStructSize = sizeof(ofn);
				ofn.hwndOwner = hWnd;
				ofn.lpstrFilter = L"图片文件(*.bmp,*.jpg,*.jpe,*.jpeg,*.png,*.gif,*.heic)\0*.bmp;*.jpg;*.jpe;*.jpeg;*.png;*.gif;*.heic;\0全部文件(*.*)\0*.*;\0\0";
				ofn.nFilterIndex = 1;
				ofn.lpstrFile = szFile;
				ofn.nMaxFile = sizeof(szFile);
				ofn.lpstrFileTitle = szFileTitle;
				ofn.nMaxFileTitle = sizeof(szFileTitle);
				ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_EXPLORER;
				if (GetOpenFileNameW(&ofn))
					ib.LoadFromFile(szFile);
			}
			else if (id == BAboutB)//关于 按钮被按下，这里显示关于窗口
			{
				if (About.IsInit())
				{
					About.Show(SW_SHOW);
					MessageBoxW(About, L"您已打开关于窗口！", L"按钮消息", MB_OK);
					break;
				}
				About.Parent = Main;

				if (!About.Create(hInst, WindowClass, Title, WndProc, AboutWidth, AboutHeight))
					return;

				AboutBack.SetTotalOpacity(0.0f);
				my.SetPosition(20, 0);
				my.SetTotalOpacity(0.0f);
				About_OK.SetTotalOpacity(0.0f);

				About.SetTransparent(true);
				About.Init(DConProc, 0.0f, 0.0f, true, 60, { 0, 0, 0, 0.0f });
				About.AddControl(&AboutBack);
				About.AddControl(&my, AboutBack);//介绍的标签
				About.AddControl(&About_OK, AboutBack);//关于窗口的“确定”键
				About.CreateRenderThread();
				About.Show(SW_SHOW);

				AboutBack.SetTotalOpacity(1.0f, 800, &b);
				my.SetPosition(20, 35, 600, &b);
				my.SetTotalOpacity(1.0f, 800, &b);
				About_OK.SetTotalOpacity(1.0f, 800, &b);
				ib.SetBackColor({ 0, 0, 0, 0.5f }, 350);
				ib.SetImageOpacity(0.5f, 800, &b);
			}
			else if (id == ShowUpdateRect)
			{
				if (Main.Dbg_GetShowUpdateRect())
				{
					Main.Dbg_SetShowUpdateRect(false);
					About.Dbg_SetShowUpdateRect(false);
					ShowUpdateRect.SetText(L"显示更新区域");
				}
				else {
					Main.Dbg_SetShowUpdateRect(true);
					About.Dbg_SetShowUpdateRect(true);
					ShowUpdateRect.SetText(L"隐藏更新区域");
				}
			}
			else if (id == SetLayered)
			{
				if (Main.GetTransparentWindow())
				{
					Dbg_Back.SetBackgroundGaussianBlur(DBG_SIGMA);
					Dock.SetBackgroundGaussianBlur(DOCK_SIGMA);
					ib.SetTotalOpacity(1.0f);
					SetLayered.SetText(L"切换透明窗口");
					Main._RenderFrame();
					Main._RenderFrame();
					Main.SetTransparent(false);
				}
				else {
					Dbg_Back.SetBackgroundGaussianBlur(0.0f);
					Dock.SetBackgroundGaussianBlur(0.0f);
					ib.SetTotalOpacity(1.0f);
					Main.SetTransparent(true);
					SetLayered.SetText(L"切换普通窗口");
					ib.SetTotalOpacity(0.7f, 1000, &b);
				}
			}
			else if (id == SetBlur)
			{
				if (Main.GetBackgroundBlur_Win10())
				{
					SetBlur.SetText(L"设置背景模糊(Win10)");
					Main.SetBackgroundBlur_Win10(false);
				}
				else {
					SetBlur.SetText(L"取消背景模糊(Win10)");
					Main.SetBackgroundBlur_Win10(true);
				}
			}
			break;
		}
		case DControlMsg::Control_StateChanged:
		{
			DControlState after = (DControlState)lParam;
			if (id == CloseB)
			{
				if (after == DControlState::MouseMove)
				{
					CloseB.SetFillColor({ 255, 255, 255, 0.25f }, 250);
				}
				else if (after == DControlState::Normal)
				{
					CloseB.SetFillColor({ 255, 255, 255, 0.0f }, 250);
					CloseB.SetRadialOpacity(0.0f, 250);
				}
			}
			else if (id == MinB)
			{
				if (after == DControlState::MouseMove)
				{
					MinB.SetFillColor({ 255, 255, 255, 0.25f }, 250);
				}
				else if (after == DControlState::Normal)
				{
					MinB.SetFillColor({ 255, 255, 255, 0.0f }, 250);
					MinB.SetRadialOpacity(0.0f, 250);
				}
			}
			else if (id == SetBackImgB)
			{
				if (after == DControlState::MouseMove)
				{
					SetBackImgB.SetFillColor({ 255, 255, 255, 0.25f }, 250);
				}
				else if (after == DControlState::Normal)
				{
					SetBackImgB.SetFillColor({ 255, 255, 255, 0.0f }, 250);
					SetBackImgB.SetRadialOpacity(0.0f, 250);
				}
			}
			else if (id == BAboutB)
			{
				if (after == DControlState::MouseMove)
				{
					BAboutB.SetFillColor({ 255, 255, 255, 0.25f }, 250);
				}
				else if (after == DControlState::Normal)
				{
					BAboutB.SetFillColor({ 255, 255, 255, 0.0f }, 250);
					BAboutB.SetRadialOpacity(0.0f, 250);
				}
			}
			break;
		}
		case DControlMsg::Control_LButtonDown:
		{
			if (id == CloseB)
			{
				CloseB.SetRadialRadius(0.0f, 0.0f);
				CloseB.SetRadialOpacity(1.0f);
				CloseB.SetRadialCenter({ (long)Main.DPToDIP(GET_X(wParam)), (long)Main.DPToDIP(GET_Y(wParam)) });
				CloseB.SetRadialRadius(70.0f, 70.0f, 200);
			}
			else if (id == MinB)
			{
				MinB.SetRadialRadius(0.0f, 0.0f);
				MinB.SetRadialOpacity(1.0f);
				MinB.SetRadialCenter({ (long)Main.DPToDIP(GET_X(wParam)), (long)Main.DPToDIP(GET_Y(wParam)) });
				MinB.SetRadialRadius(70.0f, 70.0f, 200);
			}
			else if (id == SetBackImgB)
			{
				SetBackImgB.SetRadialRadius(0.0f, 0.0f);
				SetBackImgB.SetRadialOpacity(1.0f);
				SetBackImgB.SetRadialCenter({ (long)Main.DPToDIP(GET_X(wParam)), (long)Main.DPToDIP(GET_Y(wParam)) });
				SetBackImgB.SetRadialRadius(170.0f, 170.0f, 300);
			}
			else if (id == BAboutB)
			{
				BAboutB.SetRadialRadius(0.0f, 0.0f);
				BAboutB.SetRadialOpacity(1.0f);
				BAboutB.SetRadialCenter({ (long)Main.DPToDIP(GET_X(wParam)), (long)Main.DPToDIP(GET_Y(wParam)) });
				BAboutB.SetRadialRadius(170.0f, 170.0f, 300);
			}
			break;
		}
		}
	}
	else if (hWnd == About)
	{
		if (msg == DControlMsg::Control_Click && id == About_OK)
		{
			//About.SetWindowMouseThrough(true);//鼠标穿透
			my.SetPosition(20, 20, 600, &b);
			my.SetTotalOpacity(0.0f, 800, &b);
			About_OK.SetTotalOpacity(0.0f, 800, &b);
			ib.SetImageOpacity(1.0f, 800, &b);
			ib.SetBackColor({ 0, 0, 0, 0.0f }, 350);
			AboutBack.SetTotalOpacity(0.0f, 800, &b, true, 8);
		}
	}

	return;
}
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//让DXUI处理响应的消息，来改变控件的状态
	LRESULT res = Main.DXUIMessageProc(hWnd, message, wParam, lParam);
	LRESULT res1 = About.DXUIMessageProc(hWnd, message, wParam, lParam);
	LRESULT resComm = KeyPopup.DXUIMessageProc(hWnd, message, wParam, lParam);
	LRESULT resChat = Chat.DXUIMessageProc(hWnd, message, wParam, lParam);
	LRESULT resMgr = MgrWndUI.MsgProc(hWnd, message, wParam, lParam);
	LRESULT resEdit = EditWndUI.MsgProc(hWnd, message, wParam, lParam);
	switch (message)
	{
	case WM_HOTKEY:
		if (LOWORD(lParam) == 0)
		{
			if (HIWORD(lParam) == VK_F2)
				BeginClick();
			if (HIWORD(lParam) == VK_F3)
				StopClick();
		}
		break;
	case WM_DESTROY:
		if (hWnd == Main)//如果是关于窗口销毁了，那就释放关于窗口的类
		{
			//此时为Main窗口销毁时
			UnregisterHotKey(Main, HotKeyBegin);
			UnregisterHotKey(Main, HotKeyStop);
			StopClick();

			if (About.IsInit())
				About.Release();
			if (KeyPopup.IsInit())
				KeyPopup.Release();
			if (Chat.IsInit())
				Chat.Release();
			if (MgrWnd.IsInit())
				MgrWnd.Release();
			if (EditWnd.IsInit())
				EditWnd.Release();

			PostQuitMessage(0);
		}
		break;
	case WM_TIMER:
		if (wParam == ErrTimer)
		{
			MainErr.SetTotalOpacity(0.0f, 250);
			MainErrMsg.SetTotalOpacity(0.0f, 250);
			if (ErrTimer)
			{
				KillTimer(Main, 233);
				ErrTimer = 0;
			}
		}
		else if (wParam == UpdMsgTimer)
		{
			UpdMsg.SetTotalOpacity(0.0f, 250);
			if (UpdMsgTimer)
			{
				KillTimer(Main, 234);
				UpdMsgTimer = 0;
			}
		}
		break;

	default:
		//如果返回值不为-1，则返回DXUI库处理后的返回值
		if (res != -1)
			return res;
		else if (res1 != -1)
			return res1;
		else if (resComm != -1)
			return resComm;
		else if (resChat != -1)
			return resChat;
		else if (resMgr != -1)
			return resMgr;
		else if (resEdit != -1)
			return resEdit;

		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

void __cdecl UpdateInformationThread(void* param)
{
	UpdateThreadAlive = true;
	wchar_t sOut[256];
	while (UpdateInfo)
	{
		_stprintf_s(sOut, L"系统 CPU 占用：%d %%", GetCPUUsageRate());
		CPURate.SetText(sOut);//设置文本框内容
		SetMemoryInfo();
	}
	UpdateThreadAlive = false;
	return;
}
inline unsigned long long FileTimeSub(FILETIME ftEndTime, FILETIME ftStartTime)
{
	unsigned long long nDeltaTime;

	unsigned long long nEndTime = (unsigned long long)ftEndTime.dwHighDateTime << 32 | ftEndTime.dwLowDateTime;
	unsigned long long nStartTime = (unsigned long long)ftStartTime.dwHighDateTime << 32 | ftStartTime.dwLowDateTime;

	nDeltaTime = nEndTime - nStartTime;

	return nDeltaTime;
}
inline UINT GetCPUUsageRate()
{
	FILETIME ftStartIdleTime, ftStartKernelTime, ftStartUserTime;
	FILETIME ftEndIdleTime, ftEndKernelTime, ftEndUserTime;

	GetSystemTimes(&ftStartIdleTime, &ftStartKernelTime, &ftStartUserTime);
	Sleep(UpdateDelay);
	GetSystemTimes(&ftEndIdleTime, &ftEndKernelTime, &ftEndUserTime);

	unsigned long long nDeltaIdleTime = FileTimeSub(ftEndIdleTime, ftStartIdleTime);
	unsigned long long nDeltaKernelTime = FileTimeSub(ftEndKernelTime, ftStartKernelTime);
	unsigned long long nDeltaUserTime = FileTimeSub(ftEndUserTime, ftStartUserTime);

	if (nDeltaKernelTime + nDeltaUserTime == 0)
	{
		return 0;
	}

	UINT nCPUUsageRate = (UINT)(((nDeltaKernelTime + nDeltaUserTime - nDeltaIdleTime) * 100) / (nDeltaKernelTime + nDeltaUserTime));

	return nCPUUsageRate;
}

inline void SetMemoryInfo()
{
	HANDLE hProcess;
	PROCESS_MEMORY_COUNTERS pmc;

	hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, GetCurrentProcessId());
	if (!hProcess)
		return;

	wchar_t sOut[256];
	if (GetProcessMemoryInfo(hProcess, &pmc, sizeof(pmc)))
	{
		_stprintf_s(sOut, L"内存：%.1f MB | 峰值内存：%.1f MB (不准)", pmc.WorkingSetSize / 1048576.0f, pmc.PeakWorkingSetSize / 1048576.0f);
		MemInfo.SetText(sOut);//设置文本框内容
	}
	else
		MemInfo.SetText(L"内存：0.0 MB | 峰值内存：0.0 MB (不准)");//设置文本框内容

	CloseHandle(hProcess);
}

POINT RandPoint(long Xmin, long Xmax, long Ymin, long Ymax)
{
	POINT p;
	srand((UINT)timeGetTime());
	p.x = rand() % (Xmax - Xmin) + Xmin;
	srand((UINT)(timeGetTime() + timeGetTime() * p.x));
	p.y = rand() % (Ymax - Ymin) + Ymin;
	return p;
}
