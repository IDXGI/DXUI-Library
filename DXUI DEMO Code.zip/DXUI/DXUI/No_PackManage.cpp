﻿#include "Main.h"

DWindow MgrWnd;
DLinearColorBox MgrTiB;
DLabel MgrTi;
DButton MgrClose;

DSolidColorBox ScrB;
DScrollView PackView;

DButton NewB;
DButton DelB;
DButton CacheB;

//列表相关
typedef struct _tagPackItem
{
	DSolidColorBox* Back;
	DImageBox* Icon;
	DSolidColorBox* IconB;
	DLabel* Name;
}PackItem;

std::map<UINT, PackItem> packs;
___DThreadLock packLock;
float PackFullHeight = 0.0f;
float NowX = 0.0f;
#define PackSpacing 10.0f
#define PackWidthSpacing 12.5f
#define PackWidth 120
#define PackHeight 138

//主窗口的参数定义
#define Title       L"包管理"//标题栏文本
#define WindowClass L"NoCiZhan Class"//主窗口类名
#define WindowWidth  440
#define WindowHeight 510

void __stdcall MgrDConProc(HWND hWnd, UINT id, DControlType type, DControlMsg msg, WPARAM wParam, LPARAM lParam);

void AddPack();

bool PackMgrUI::Show(WNDPROC Proc, HWND Parent)
{
	if (MgrWnd.IsInit())
		return true;

	MgrWnd.Parent = Parent;
	MgrWnd.ExStyle = WS_EX_TOOLWINDOW;
	if (!MgrWnd.Create(hInst, WindowClass, Title, Proc, WindowWidth, WindowHeight))
		return false;

	//使用步骤：初始化各个控件及窗口 —— 向窗口添加控件 —— 创建渲染线程
	if (!MgrTiB.IsInit())
	{
		DColorBox_Point p[2];
		p[0].color = { 0, 236, 116, 1.0f };
		p[0].position = 0.0f;
		p[1].color = { 0, 174, 247, 1.0f };
		p[1].position = 1.0f;

		MgrTiB.Init({ 0, 0 }, { WindowWidth, 40 }, { 0, 0, 0, 0.0f }, p, 2, { 0, 40 }, { WindowWidth, 0 }, { 0 }, 0.0f, 0.0f, 0.0f, true);

		MgrTi.Init({ 150, 0 }, { WindowWidth - 300, 40 },
			{ { 255, 255, 255, 1.0f }, false, false, 0 },
			{ { 255, 255, 255, 1.0f }, false, false, 0 },
			{ { 255, 255, 255, 1.0f }, false, false, 0 },
			true, Title, L"微软雅黑", 20, false, DFontWeight::Medium, DAlignment::Center, DAlignment::Center);

		MgrClose.Init({ WindowWidth - 35, 0 }, { 35, 35 },
			{ { 255, 60, 40, 0.0f }, { 0, 0, 0, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
			{ { 255, 70, 50, 0.8f }, { 200, 200, 200, 0.0f }, { 255, 255, 255, 1.0f }, 250 },
			{ { 150, 50, 30, 1.0f }, { 150, 150, 200, 0.0f }, { 255, 255, 255, 1.0f }, 50 },
			{ { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, { 0, 0, 0, 1.0f }, 300 },
			0.0f, 0.0f, 0.0f, L"✕", L"微软雅黑", 18, DFontWeight::Normal);

		ScrB.Init({ 15, 50 }, { WindowWidth - 30, 385 }, { 0, 0, 0, 0.0f }, { 217, 217, 217, 1.0f }, 1.0f, 5.0f, 5.0f);
		PackView.Init({ 15, 50 }, { WindowWidth - 30, 385 }, 0.0f, 70.0f, 200, true, true);

		NewB.Init({ 15, 450 }, { 130, 45 },
			{ { 230, 230, 230, 1.0f }, { 0, 0, 0, 0.0f }, { 64, 64, 64, 1.0f }, 200 },
			{ { 190, 190, 190, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 150 },
			{ { 130, 130, 130, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 50 },
			{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, 300 },
			7.0f, 7.0f, 0.0f, L"新建包", L"微软雅黑", 20);
		DelB.Init({ 155, 450 }, { 130, 45 },
			{ { 230, 230, 230, 1.0f }, { 0, 0, 0, 0.0f }, { 64, 64, 64, 1.0f }, 200 },
			{ { 190, 190, 190, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 200 },
			{ { 130, 130, 130, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 50 },
			{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, 300 },
			7.0f, 7.0f, 0.0f, L"删除包", L"微软雅黑", 20);
		CacheB.Init({ 295, 450 }, { 130, 45 },
			{ { 230, 230, 230, 1.0f }, { 0, 0, 0, 0.0f }, { 64, 64, 64, 1.0f }, 200 },
			{ { 190, 190, 190, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 150 },
			{ { 130, 130, 130, 1.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 1.0f }, 50 },
			{ { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, { 0, 0, 0, 0.0f }, 300 },
			7.0f, 7.0f, 0.0f, L"备份包", L"微软雅黑", 20);
	}
	PackView.SetFullHeight(0.0f);
	PackFullHeight = 0.0f;
	NowX = 0.0f;
	//主窗口初始化
	MgrWnd.Init(MgrDConProc, 3.7f, 0.0f, true, 60);

	MgrWnd.AddControl(&MgrTiB);
	MgrWnd.AddControl(&MgrTi, MgrTiB, true);
	MgrWnd.AddControl(&MgrClose, MgrTiB);
	MgrWnd.AddControl(&ScrB);
	MgrWnd.AddControl(&PackView, ScrB);
	MgrWnd.AddControl(&NewB);
	MgrWnd.AddControl(&DelB);
	MgrWnd.AddControl(&CacheB);

	MgrWnd.CreateRenderThread();
	MgrWnd.Dbg_SetShowUpdateRect(false);
	MgrWnd.Show();
	MgrWnd.SetShadowAlpha(0.4f, 200);

	return true;
}

LRESULT CALLBACK PackMgrUI::MsgProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	return MgrWnd.DXUIMessageProc(hWnd, message, wParam, lParam);
}


void __stdcall MgrDConProc(HWND hWnd, UINT id, DControlType type, DControlMsg msg, WPARAM wParam, LPARAM lParam)
{
	if (hWnd == MgrWnd)
	{
		switch (msg)
		{
		case DControlMsg::Control_Click://这里响应的按钮的按下操作
		{
			if (id == MgrClose)//关闭按钮被按下
			{
				MgrWnd.Release();

				packLock.Lock();
				std::map<UINT, PackItem>::iterator it = packs.begin();
				while (it != packs.end())
				{
					it->second.Back->Release();
					it->second.IconB->Release();
					it->second.Icon->Release();
					it->second.Name->Release();
					++it;
				}
				packs.clear();
				packLock.Unlock();
			}
			if (id == NewB)
			{
				AddPack();
			}
			else if (type == DControlType::SolidColorBox)
			{
				packLock.Lock();
				std::map<UINT, PackItem>::iterator packit = packs.find(id);
				if (packit != packs.end())
				{
					//进入包编辑页面
					EditWndUI.Show(WndProc, MgrWnd);
				}
				packLock.Unlock();
			}
			break;
		}
		case DControlMsg::Control_StateChanged:
		{
			DControlState after = (DControlState)lParam;
			packLock.Lock();
			std::map<UINT, PackItem>::iterator packit = packs.find(id);
			if (packit != packs.end())
			{
				if (after == DControlState::MouseMove)
				{
					packit->second.Back->SetFillColor({ 180, 180, 180, 1.0f }, 200);
					packit->second.Icon->SetTotalOpacity(0.7f, 200);
					packit->second.Name->SetTotalOpacity(0.85f, 200);
				}
				else if (after == DControlState::Normal)
				{
					packit->second.Back->SetFillColor({ 237, 237, 237, 1.0f }, 200);
					packit->second.Icon->SetTotalOpacity(0.95f, 200);
					packit->second.Name->SetTotalOpacity(0.95f, 200);
				}
				else if (after == DControlState::Click)
				{
					packit->second.Back->SetFillColor({ 150, 150, 150, 1.0f }, 100);
					packit->second.Icon->SetTotalOpacity(0.6f, 100);
					packit->second.Name->SetTotalOpacity(0.8f, 100);
				}
			}
			packLock.Unlock();
			break;
		}
		}
	}
	return;
}


void AddPack()
{
	//检测列表是否换行
	if (NowX + PackWidth > 385.0f)
	{
		NowX = 0.0f;
		PackFullHeight += PackHeight + PackSpacing;
		PackView.SetFullHeight(PackFullHeight + PackHeight + PackSpacing * 2.0f);
	}
	PackView.SetScrollOffset(PackView.GetFullHeight() - PackView.GetHeight(), 300, &b);

	NowX += PackWidthSpacing;

	PackItem pait;
	pait.Back = new DSolidColorBox;
	pait.Icon = new DImageBox;
	pait.IconB = new DSolidColorBox;
	pait.Name = new DLabel;

	if (!pait.Back || !pait.Icon || !pait.Name)
		return;
	
	pait.Back->Init({ 15 + (long)(NowX + PackWidth * 0.5f), 50 + (long)(PackFullHeight + PackSpacing + PackHeight * 0.5f) }, { 0, 0 }, { 237, 237, 237, 1.0f }, { 0, 0, 0, 0.0f }, 0.0f, 8.0f, 8.0f);
	//图片大小覆盖了文字范围，设置一下控件裁剪
	pait.IconB->Init({ 15 + (long)NowX, 50 + (long)(PackFullHeight + PackSpacing) - 2 }, { PackWidth, PackWidth - 15 }, { 0 }, { 0 });
	pait.Icon->Init({ 15 + (long)NowX, 50 + (long)(PackFullHeight + PackSpacing) - 2 }, { PackWidth, PackWidth - 5 }, false, DScaleMode::Fill);
	pait.Icon->LoadFromResource(PIC_PACK, L"png", nullptr);

	pait.Name->Init({ 20 + (long)NowX, 50 + (long)(PackFullHeight + PackSpacing) + PackWidth - 15 }, { 110, 25 },
		{ { 50, 50, 50, 1.0f }, false, false, 0 },
		{ { 50, 50, 50, 1.0f }, false, false, 0 },
		{ { 50, 50, 50, 1.0f }, false, false, 0 },
		true, L"必修一", L"微软雅黑", 18, false, DFontWeight::Medium, DAlignment::Center, DAlignment::Center);

	//添加插入动画
	pait.Back->SetTotalOpacity(0.0f);
	pait.IconB->SetTotalOpacity(0.0f);
	pait.Icon->SetTotalOpacity(0.0f);
	pait.Name->SetTotalOpacity(0.0f);

	pait.Back->SetTotalOpacity(1.0f, 150);
	pait.Icon->SetTotalOpacity(0.95f, 170);
	pait.Name->SetTotalOpacity(0.95f, 150);

	pait.Back->SetPosition(15 + NowX, 50.0f + PackFullHeight + PackSpacing, 250, &b);
	pait.Back->SetSize(PackWidth, PackHeight, 250, &b);

	MgrWnd.AddControl(pait.Back, PackView);
	MgrWnd.AddControl(pait.IconB, pait.Back->GetID(), true);
	MgrWnd.AddControl(pait.Icon, pait.IconB->GetID(), true);
	MgrWnd.AddControl(pait.Name, pait.Back->GetID(), true);

	packLock.Lock();
	packs.insert(std::pair<UINT, PackItem>(pait.Back->GetID(), pait));
	packLock.Unlock();

	NowX += PackWidth;
	return;
}